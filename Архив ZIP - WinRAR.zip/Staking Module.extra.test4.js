const { expect } = require("chai");
const { ethers, network } = require("hardhat");

// Размер стейка (BigInt в ethers v6)
const STAKE_AMOUNT = ethers.parseUnits("100", 8);

describe("StakingModule - Admin, Pause, and AllowedCaller", function () {
  let stakingModule, token, nftDiscount;
  let owner, user, treasury, allowedCaller;

  beforeEach(async function () {
    [owner, user, treasury, allowedCaller] = await ethers.getSigners();

    // 1) Deploy ERC20Mock
    const ERC20Mock = await ethers.getContractFactory("ERC20Mock");
    token = await ERC20Mock.deploy("TestToken", "TT", owner.address, ethers.parseUnits("10000000", 8));
    await token.waitForDeployment();

    // 2) Distribute tokens
    await token.transfer(user.address, ethers.parseUnits("1000", 8));
    await token.transfer(treasury.address, ethers.parseUnits("1000", 8));

    // 3) Deploy NFTDiscount
    const NFTDiscount = await ethers.getContractFactory("NFTDiscount");
    nftDiscount = await NFTDiscount.deploy();
    await nftDiscount.waitForDeployment();
    // NFTDiscount должен знать про StakingModule, но мы зададим daoModule после деплоя StakingModule

    // 4) Deploy StakingModule
    const StakingModule = await ethers.getContractFactory("StakingModule");
    stakingModule = await StakingModule.deploy(token.target, nftDiscount.target);
    await stakingModule.waitForDeployment();

    // 5) Настроить NFTDiscount: StakingModule как DAO-модуль
    await nftDiscount.connect(owner).setDAOModule(stakingModule.target);

    // 6) Установить treasury и дать ему allowance для автопополнения
    await stakingModule.connect(owner).setTreasury(treasury.address);
    await token.connect(treasury).approve(stakingModule.target, ethers.parseUnits("1000", 8));

    // 7) Разрешения на списание у пользователя и у allowedCaller
    await token.connect(user).approve(stakingModule.target, STAKE_AMOUNT);
    await token.connect(allowedCaller).approve(stakingModule.target, STAKE_AMOUNT);

    // 8) Назначить allowedCaller
    await stakingModule.connect(owner).setAllowedCaller(allowedCaller.address);
  });

  describe("Admin functions", function () {
    it("only owner can setRewardConfig and setAllowedCaller", async function () {
      // Non-owner
      await expect(
        stakingModule.connect(user).setRewardConfig(6, 2, 5)
      ).to.be.revertedWith("Ownable: caller is not the owner");

      // Owner
      await stakingModule.connect(owner).setRewardConfig(6, 2, 5);
      const cfg = await stakingModule.rewardConfigs(6);
      expect(cfg.nftCount).to.equal(2);
      expect(cfg.discountPercent).to.equal(5);

      // Non-owner cannot change allowedCaller
      await expect(
        stakingModule.connect(user).setAllowedCaller(user.address)
      ).to.be.revertedWith("Ownable: caller is not the owner");
    });
  });

  describe("Pause / Unpause", function () {
    it("pause blocks stake and unstake", async function () {
      // 1) Пауза
      await stakingModule.connect(owner).pause();

      // Стейк должен revert
      await expect(
        stakingModule.connect(user).stakeTokensFor(user.address, STAKE_AMOUNT, 3)
      ).to.be.revertedWith("Pausable: paused");

      // 2) Снятие паузы
      await stakingModule.connect(owner).unpause();

      // Теперь стейк проходит
      await expect(
        stakingModule.connect(user).stakeTokensFor(user.address, STAKE_AMOUNT, 3)
      ).to.emit(stakingModule, "Staked");

      // 3) Пауза перед unstake
      await stakingModule.connect(owner).pause();

      // Unstake должен revert
      await expect(
        stakingModule.connect(user).unstakeTokens()
      ).to.be.revertedWith("Pausable: paused");
    });
  });

  describe("AllowedCaller functionality", function () {
    it("allowedCaller can stake and unstake on behalf of user", async function () {
      // allowedCaller делает стейк за user
      await expect(
        stakingModule.connect(allowedCaller).stakeTokensFor(user.address, STAKE_AMOUNT, 3)
      ).to.emit(stakingModule, "Staked");

      // Продвинем время, чтобы unstake не упал в раннюю ветку без автопополнения
      const threeMonths = 3 * 30 * 24 * 3600;
      await network.provider.send("evm_increaseTime", [threeMonths + 1]);
      await network.provider.send("evm_mine");

      // Treasury уже имеет allowance, поэтому можно unstake
      await expect(
        stakingModule.connect(allowedCaller).unstakeTokensFor(user.address, 0)
      ).to.emit(stakingModule, "Unstaked");

      // Проверяем, что у user больше нет активных стейков
      expect(await stakingModule.getStakeCount(user.address)).to.equal(0);
    });
  });
});
