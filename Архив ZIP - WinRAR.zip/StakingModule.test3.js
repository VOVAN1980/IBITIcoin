// test/StakingModule.test.js
const { expect } = require("chai");
const { ethers, network } = require("hardhat");
const { parseUnits } = require("ethers");

describe("StakingModule", function() {
  let token, nftDiscount, staking;
  let owner, user, other;
  const ONE_TOKEN = parseUnits("100", 8); // 100 токенов, 8 дец. :contentReference[oaicite:1]{index=1}
  const DURATION = 3; // месяцев
  const REQUIRED_TIME = DURATION * 30 * 24 * 3600;
  const GRACE = 180 * 24 * 3600;

  beforeEach(async () => {
    [owner, user, other] = await ethers.getSigners();

    // 1) Деплой токена и раздача user=1000
    const ERC20Mock = await ethers.getContractFactory("ERC20Mock", owner);
    token = await ERC20Mock.deploy(
      "MockToken", "MTK", user.address, parseUnits("1000", 8)
    );
    await token.waitForDeployment();

    // 2) Даем owner 200 токенов для treasury
    await token.connect(user).transfer(owner.address, parseUnits("200", 8));

    // 3) Деплой NFTDiscount и StakingModule
    const NFTDiscount = await ethers.getContractFactory("NFTDiscount", owner);
    nftDiscount = await NFTDiscount.deploy();
    await nftDiscount.waitForDeployment();

    const SM = await ethers.getContractFactory("StakingModule", owner);
    staking = await SM.deploy(token.target, nftDiscount.target);
    await staking.waitForDeployment();

    // 4) Настройка: DAO‑модуль для NFT, treasury, approve
    await nftDiscount.connect(owner).setDAOModule(staking.target);
    await staking.connect(owner).setTreasury(owner.address);
    await token.connect(user).approve(staking.target, parseUnits("1000", 8));
  });

  it("applies penalty on early unstake", async () => {
    // Начальные балансы
    const balUser0 = await token.balanceOf(user.address);   // 800 токенов
    const balOwner0 = await token.balanceOf(owner.address); // 200 токенов

    // Stake 100
    await staking.connect(user).stakeTokensFor(user.address, ONE_TOKEN, DURATION);

    // Early unstake
    const penaltyPct = await staking.getPenaltyPercentage(DURATION);
    const penalty = ONE_TOKEN * penaltyPct / 100n; // 5% от 100 = 5
    const tx = await staking.connect(user).unstakeTokensFor(user.address, 0);
    await tx.wait();

    // После: пользователь потерял штраф
    const balUser1 = await token.balanceOf(user.address);
    expect(balUser1).to.equal(balUser0 - penalty);

    // Контракт держит штраф
    const balContract = await token.balanceOf(staking.target);
    expect(balContract).to.equal(penalty);

    // Всего стейков нет
    expect(await staking.getStakeCount(user.address)).to.equal(0);
    expect(await staking.totalStaked()).to.equal(0);
  });

  it("gives reward and NFTs on on-time unstake", async () => {
    // Начальные балансы
    const balUser0 = await token.balanceOf(user.address);   // 800
    const balOwner0 = await token.balanceOf(owner.address); // 200

    // Stake 100
    await staking.connect(user).stakeTokensFor(user.address, ONE_TOKEN, DURATION);

    // Treasury approve reward
    const rewardPct = await staking.getRewardPercentage(DURATION);
    const reward = ONE_TOKEN * rewardPct / 100n; // 5% от 100 = 5
    await token.connect(owner).approve(staking.target, reward);

    // Ждём окончания срока
    await network.provider.send("evm_increaseTime", [REQUIRED_TIME]);
    await network.provider.send("evm_mine");

    // Unstake on-time
    await expect(staking.connect(user).unstakeTokensFor(user.address, 0))
      .to.emit(staking, "Unstaked")
      .withArgs(user.address, ONE_TOKEN, reward, 0, 2, false);

    // Пользователь получил reward
    const balUser1 = await token.balanceOf(user.address);
    expect(balUser1).to.equal(balUser0 + reward);

    // Treasury (owner) потратил reward
    const balOwner1 = await token.balanceOf(owner.address);
    expect(balOwner1).to.equal(balOwner0 - reward);

    // Пользователь получил 2 NFT
    expect(await nftDiscount.balanceOf(user.address)).to.equal(2);

    expect(await staking.getStakeCount(user.address)).to.equal(0);
    expect(await staking.totalStaked()).to.equal(0);
  });

  it("sends all to treasury on expired unstake", async () => {
    // Начальные балансы
    const balUser0 = await token.balanceOf(user.address);   // 800
    const balOwner0 = await token.balanceOf(owner.address); // 200

    // Stake 100
    await staking.connect(user).stakeTokensFor(user.address, ONE_TOKEN, DURATION);

    // Ждём grace + 1
    await network.provider.send("evm_increaseTime", [REQUIRED_TIME + GRACE + 1]);
    await network.provider.send("evm_mine");

    // Unstake expired
    await expect(staking.connect(user).unstakeTokensFor(user.address, 0))
      .to.emit(staking, "Unstaked")
      .withArgs(user.address, ONE_TOKEN, 0, 0, 0, true)
      .and.to.emit(staking, "PenaltyTokensTransferred")
      .withArgs(owner.address, ONE_TOKEN);

    // Treasury получил principal
    const balOwner1 = await token.balanceOf(owner.address);
    expect(balOwner1).to.equal(balOwner0 + ONE_TOKEN);

    // Пользователь потерял stake
    const balUser1 = await token.balanceOf(user.address);
    expect(balUser1).to.equal(balUser0 - ONE_TOKEN);

    expect(await staking.getStakeCount(user.address)).to.equal(0);
    expect(await staking.totalStaked()).to.equal(0);
  });

  it("pauses and unpauses staking and unstaking", async () => {
    await staking.connect(owner).pause();
    await expect(
      staking.connect(user).stakeTokensFor(user.address, ONE_TOKEN, DURATION)
    ).to.be.revertedWith("Pausable: paused");
    await staking.connect(owner).unpause();

    await staking.connect(user).stakeTokensFor(user.address, ONE_TOKEN, DURATION);
    await staking.connect(owner).pause();
    await expect(
      staking.connect(user).unstakeTokensFor(user.address, 0)
    ).to.be.revertedWith("Pausable: paused");
  });
});
