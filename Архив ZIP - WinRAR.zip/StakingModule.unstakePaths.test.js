const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("StakingModule – unstake paths coverage (193, 262)", () => {
  let staking, token, nft, treasury, owner, user;

  beforeEach(async () => {
    [owner, user, treasury] = await ethers.getSigners();

    // Инициализация токена и раздача
    const ERC20Mock = await ethers.getContractFactory("ERC20Mock");
    token = await ERC20Mock.deploy("IBI", "IBI", owner.address, ethers.parseUnits("2000", 8));
    await token.transfer(user.address, ethers.parseUnits("1000", 8));
    await token.transfer(treasury.address, ethers.parseUnits("1000", 8));

    // NFT и staking
    const NFT = await ethers.getContractFactory("NFTDiscount");
    nft = await NFT.deploy();

    const Staking = await ethers.getContractFactory("StakingModule");
    staking = await Staking.deploy(token.target, nft.target);

    // Настройки контракта
    await staking.setTreasury(treasury.address);
    await staking.setAllowedCaller(owner.address);
    await staking.setRewardConfig(1, 1, 5); // 1 месяц = 1 NFT, 5% скидка

    // ⚠️ Важно: staking становится owner у NFTDiscount
    await nft.transferOwnership(staking.target);

    // Апрувы
    await token.connect(user).approve(staking.target, ethers.MaxUint256);
    await token.connect(treasury).approve(staking.target, ethers.MaxUint256);
  });

  it("should apply penalty on early unstake (line 193)", async () => {
    await staking.connect(user).stakeTokensFor(user.address, ethers.parseUnits("100", 8), 1);

    const block = await ethers.provider.getBlock("latest");
    await ethers.provider.send("evm_setNextBlockTimestamp", [block.timestamp + 10 * 24 * 60 * 60]); // 10 дней
    await ethers.provider.send("evm_mine");

    const tx = await staking.connect(user).unstakeTokens();
    await expect(tx).to.emit(staking, "Unstaked");
  });

  it("should give reward and NFTs during grace period (line 262)", async () => {
    await staking.connect(user).stakeTokensFor(user.address, ethers.parseUnits("200", 8), 1);

    const block = await ethers.provider.getBlock("latest");
    await ethers.provider.send("evm_setNextBlockTimestamp", [block.timestamp + 35 * 24 * 60 * 60]); // 35 дней
    await ethers.provider.send("evm_mine");

    const tx = await staking.connect(user).unstakeTokens();
    await expect(tx).to.emit(staking, "Unstaked");
  });

    it("should send full amount to treasury after grace period (line 278)", async () => {
  await staking.connect(user).stakeTokensFor(user.address, ethers.parseUnits("300", 8), 1); // 1 месяц

  const block = await ethers.provider.getBlock("latest");
  await ethers.provider.send("evm_setNextBlockTimestamp", [block.timestamp + 200 * 24 * 60 * 60]); // >180 дней
  await ethers.provider.send("evm_mine");

  const tx = await staking.connect(user).unstakeTokens();
  await expect(tx).to.emit(staking, "Unstaked");
 });
});
