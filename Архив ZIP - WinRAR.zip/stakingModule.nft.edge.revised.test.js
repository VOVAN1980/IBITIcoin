
const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("StakingModule – Edge cases for NFT minting", function () {
  let owner, user, attacker;
  let token, staking, nftDiscount;

  beforeEach(async function () {
    [owner, user, attacker] = await ethers.getSigners();

    const ERC20 = await ethers.getContractFactory("ERC20Mock");
    token = await ERC20.deploy("MOCK", "MOCK", owner.address, ethers.parseUnits("1000000", 18));
    await token.waitForDeployment();

    const NFTDiscount = await ethers.getContractFactory("NFTDiscount");
    nftDiscount = await NFTDiscount.deploy();
    await nftDiscount.waitForDeployment();

    const StakingModule = await ethers.getContractFactory("StakingModule");
    staking = await StakingModule.deploy(token.target, nftDiscount.target);
    await staking.waitForDeployment();

    await nftDiscount.setJackpotMinter(staking.target, true);
  });

  it("1. Does not mint NFT if unstaked early", async () => {
    await staking.setTreasury(owner.address);
    await staking.setRewardConfig(6, 2, 5);

    const amount = ethers.parseUnits("100", 18);
    await token.transfer(user.address, amount);
    await token.connect(user).approve(staking.target, amount);
    await staking.connect(user).stakeTokensFor(user.address, amount, 6);

    await ethers.provider.send("evm_increaseTime", [60 * 24 * 60 * 60]);
    await ethers.provider.send("evm_mine");

    await token.transfer(staking.target, ethers.parseUnits("200", 18));
    await staking.connect(user).unstakeTokensFor(user.address, 0);

    const balance = await nftDiscount.balanceOf(user.address);
    expect(balance).to.equal(0n);
  });

  it("2. Reverts on duplicate URI mint", async () => {
    const uri = "ipfs://uri#duplicate";

    await nftDiscount.setJackpotMinter(owner.address, true);
    await nftDiscount.mintJackpot(user.address, 3, uri);

    await expect(
      nftDiscount.mintJackpot(user.address, 3, uri)
    ).to.be.revertedWith("URI already used");
  });

  it("3. Burns Jackpot NFT on use", async () => {
    const uri = "ipfs://uri#burnonuse";
    await nftDiscount.setJackpotMinter(owner.address, true);
    await nftDiscount.mintJackpot(user.address, 3, uri);

    const tokenId = 0;
    // Используем NFT (вызовет _burn)
    await nftDiscount.connect(user).useDiscount(tokenId);

    // Проверяем, что токен больше не существует
    await expect(
      nftDiscount.ownerOf(tokenId)
    ).to.be.revertedWith("ERC721: invalid token ID");
  });

  it("4. Reverts if mintJackpot called by unauthorized", async () => {
    await expect(
      nftDiscount.connect(attacker).mintJackpot(user.address, 3, "ipfs://uri#unauth")
    ).to.be.revertedWith("Not authorized for Jackpot mint");
  });

  it("5. Reverts unstake if treasury is not set", async () => {
    const amount = ethers.parseUnits("100", 18);
    await token.transfer(user.address, amount);
    await token.connect(user).approve(staking.target, amount);
    await staking.connect(user).stakeTokensFor(user.address, amount, 6);

    await ethers.provider.send("evm_increaseTime", [6 * 30 * 24 * 60 * 60]);
    await ethers.provider.send("evm_mine");

    await expect(
      staking.connect(user).unstakeTokensFor(user.address, 0)
    ).to.be.revertedWith("Treasury not set");
  });
});
