const { expect } = require("chai");
const { ethers } = require("hardhat");
const { anyValue } = require("@nomicfoundation/hardhat-chai-matchers/withArgs");

// Функция для получения адреса задеплоенного контракта.
// Если .address отсутствует, пробуем использовать .target.
function getAddress(contractInstance) {
  return contractInstance.address || contractInstance.target || "0x0000000000000000000000000000000000000000";
}

function checkAddress(contractName, contractInstance) {
  const addr = getAddress(contractInstance);
  if (!addr || addr === "0x0000000000000000000000000000000000000000") {
    console.error(`${contractName} has a null or zero address: ${addr}`);
  } else {
    console.log(`${contractName} address: ${addr}`);
  }
}

describe("NFTSaleManager — extra coverage", function () {
  let nftSaleManager, nftDiscount;
  let ibitiToken, usdtToken; // токены для покупки NFT
  let priceOracle;          // VolumeWeightedOracle
  let owner, buyer;
  let pool;

  beforeEach(async function () {
    [owner, buyer] = await ethers.getSigners();

    // 1. Деплой NFTDiscount
    const NFTDiscount = await ethers.getContractFactory("NFTDiscount");
    nftDiscount = await NFTDiscount.deploy();
    await nftDiscount.waitForDeployment();
    checkAddress("NFTDiscount", nftDiscount);

    // 2. Деплой IBITI токена (ERC20Mock, 8 десятичных знаков)
    const ERC20Mock = await ethers.getContractFactory("ERC20Mock");
    ibitiToken = await ERC20Mock.deploy("IBITI", "IBI", owner.address, ethers.parseUnits("10000000", 8));
    await ibitiToken.waitForDeployment();
    checkAddress("IBITI Token", ibitiToken);

    // 3. Деплой USDT токена (ERC20Mock, 8 десятичных знаков)
    usdtToken = await ERC20Mock.deploy("USDT", "USDT", owner.address, ethers.parseUnits("10000000", 8));
    await usdtToken.waitForDeployment();
    checkAddress("USDT Token", usdtToken);

    // 4. Деплой VolumeWeightedOracle с 8 десятичными знаками
    const VolumeWeightedOracle = await ethers.getContractFactory("VolumeWeightedOracle");
    priceOracle = await VolumeWeightedOracle.deploy(8);
    await priceOracle.waitForDeployment();
    checkAddress("VolumeWeightedOracle", priceOracle);

    // 5. Создаем пул для oracle – MockUniswapV2Pair.
    const MockUniswapV2Pair = await ethers.getContractFactory("MockUniswapV2Pair");
    const reserve0 = 1000000;
    const reserve1 = 2000 * 1e6;
    pool = await MockUniswapV2Pair.deploy(reserve0, reserve1);
    await pool.waitForDeployment();
    checkAddress("MockUniswapV2Pair", pool);

    // Добавляем пул в oracle (вызов от владельца)
    await priceOracle.connect(owner).addPool(pool.target);

    // 6. Деплой NFTSaleManager, передавая адреса через .target (как в рабочем тесте)
    const NFTSaleManager = await ethers.getContractFactory("NFTSaleManager");
    nftSaleManager = await NFTSaleManager.deploy(
      nftDiscount.target,
      ibitiToken.target,
      usdtToken.target,
      priceOracle.target
    );
    await nftSaleManager.waitForDeployment();
    checkAddress("NFTSaleManager", nftSaleManager);

    // Важно! Авторизуем NFTSaleManager как daoModule в NFTDiscount.
    await nftDiscount.connect(owner).setDAOModule(nftSaleManager.target);

    // 7. Устанавливаем цену NFT для discountPercent = 5 (например, 500 центов = $5.00)
    await nftSaleManager.connect(owner).setNFTPrice(5, 500);

    // Шаг 8 (установка параметров USDT) убран – теперь цена одинаковая для всех способов оплаты.

    // 9. Переводим токены покупателю и устанавливаем allowance для NFTSaleManager.
    await ibitiToken.transfer(buyer.address, ethers.parseUnits("1000", 8));
    await ibitiToken.connect(buyer).approve(nftSaleManager.target, ethers.parseUnits("1000", 8));
    await usdtToken.transfer(buyer.address, ethers.parseUnits("1000", 8));
    await usdtToken.connect(buyer).approve(nftSaleManager.target, ethers.parseUnits("1000", 8));
  });

  describe("Buy NFT with IBITI", function () {
    it("should revert buyNFTWithIBITI when price not set", async function () {
      // Для discountPercent = 10 устанавливаем цену равной 0, чтобы вызвать revert.
      await nftSaleManager.connect(owner).setNFTPrice(10, 0);
      await expect(
        nftSaleManager.connect(buyer).buyNFTWithIBITI(10, "ipfs://someURI")
      ).to.be.revertedWith("Price not set");
    });

    it("should allow buyNFTWithIBITI at correct rate and mint NFT", async function () {
      // Для discountPercent = 5, цена = 500 центов.
      // Расчет:
      // currentPrice = (reserve1 * 10^(oracleDecimals)) / reserve0
      //              = (2000e6 * 1e8) / 1e6 = 2000e8.
      // IBITIAmount = (priceUSD * 1e14) / currentPrice = (500 * 1e14) / (2000e8) = 250000.
      const expectedIBITIAmount = 250000;

      await expect(nftSaleManager.connect(buyer).buyNFTWithIBITI(5, "ipfs://uniqueURI1"))
        .to.emit(nftSaleManager, "NFTPurchased")
        .withArgs(buyer.address, anyValue, anyValue, ibitiToken.target);

      const currentIbitiPrice = await nftSaleManager.getCurrentIBITIPrice(5);
      expect(currentIbitiPrice).to.equal(expectedIBITIAmount);
    });
  });

  describe("Buy NFT with USDT", function () {
    it("should revert buyNFTWithUSDT when price not set", async function () {
      // Для discountPercent = 5 задаем цену равной 0 — ожидаем revert.
      await nftSaleManager.connect(owner).setNFTPrice(5, 0);
      await expect(
        nftSaleManager.connect(buyer).buyNFTWithUSDT(5, "ipfs://uniqueURI2")
      ).to.be.revertedWith("Price not set");
    });

    it("should allow buyNFTWithUSDT at correct rate and mint NFT", async function () {
      // Для discountPercent = 5, цена = 500 центов.
      // getCurrentUSDTPrice = 500 * (10^(decimals - 2)) при decimals = 8 → 500 * 1e6 = 500,000,000.
      const expectedUSDTPrice = 500000000;
      const currentUsdtPrice = await nftSaleManager.getCurrentUSDTPrice(5);
      expect(currentUsdtPrice).to.equal(expectedUSDTPrice);

      await expect(nftSaleManager.connect(buyer).buyNFTWithUSDT(5, "ipfs://uniqueURI3"))
        .to.emit(nftSaleManager, "NFTPurchased")
        .withArgs(buyer.address, anyValue, anyValue, usdtToken.target);
    });
  });

  describe("Get current prices", function () {
    it("should return correct current prices for IBITI and USDT", async function () {
      const expectedIbiti = 250000;
      const expectedUSDT = 500000000;
      const currentIbitiPrice = await nftSaleManager.getCurrentIBITIPrice(5);
      const currentUsdtPrice = await nftSaleManager.getCurrentUSDTPrice(5);
      expect(currentIbitiPrice).to.equal(expectedIbiti);
      expect(currentUsdtPrice).to.equal(expectedUSDT);
    });
  });
});
