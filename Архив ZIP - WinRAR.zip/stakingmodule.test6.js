const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("StakingModule: unstake branches", function () {
  let deployer, treasury, user;
  let token, discount, staking;
  const DECIMALS = 8;
  const { parseUnits } = ethers;

  // Вспомогательная функция для перемотки времени
  async function warp(seconds) {
    await ethers.provider.send("evm_increaseTime", [seconds]);
    await ethers.provider.send("evm_mine", []);
  }

  beforeEach(async function () {
    [deployer, treasury, user] = await ethers.getSigners();

    // 1) Deploy ERC20Mock
    const ERC20Mock = await ethers.getContractFactory("ERC20Mock");
    token = await ERC20Mock.deploy(
      "Test Token",
      "TST",
      deployer.address,
      parseUnits("1000", DECIMALS)
    );
    await token.waitForDeployment();

    // 2) Deploy NFTDiscount
    const NFTDiscountCF = await ethers.getContractFactory("NFTDiscount");
    discount = await NFTDiscountCF.deploy();
    await discount.waitForDeployment();

    // 3) Deploy StakingModule
    const StakingCF = await ethers.getContractFactory("StakingModule");
    staking = await StakingCF.deploy(token.target, discount.target);
    await staking.waitForDeployment();

    // 4) Set treasury and fund it
    await staking.connect(deployer).setTreasury(treasury.address);
    await token.connect(deployer).transfer(treasury.address, parseUnits("500", DECIMALS));
    await token.connect(treasury).approve(staking.target, ethers.MaxUint256);

    // 5) Fund user
    await token.connect(deployer).transfer(user.address, parseUnits("100", DECIMALS));

    // 6) Allow staking contract to mint NFTs
    await discount.connect(deployer).setDAOModule(staking.target);
  });

  it("Early unstake: applies penalty, no reward, no NFTs", async function () {
    const duration = 3; // месяцев
    const amount = parseUnits("50", DECIMALS); // bigint

    // stake
    await token.connect(user).approve(staking.target, amount);
    await staking.connect(user).stakeTokensFor(user.address, amount, duration);

    // warp на requiredTime - 10s
    const required = BigInt(duration) * BigInt(30 * 24 * 3600);
    await warp(Number(required - 10n));

    // snapshot
    const balBefore = await token.balanceOf(user.address); // bigint
    const treasBefore = await token.balanceOf(treasury.address);
    const nftBefore = await discount.balanceOf(user.address);

    // unstake
    await staking.connect(user).unstakeTokensFor(user.address, 0);

    // penalty = amount * 5% (getPenaltyPercentage(3) == 5)
    const penalty = amount * 5n / 100n;
    const expectedPayout = amount - penalty;

    const balAfter = await token.balanceOf(user.address);
    expect(balAfter - balBefore).to.equal(expectedPayout);

    // treasury не изменился
    const treasAfter = await token.balanceOf(treasury.address);
    expect(treasAfter).to.equal(treasBefore);

    // NFT не появилось
    const nftAfter = await discount.balanceOf(user.address);
    expect(nftAfter).to.equal(nftBefore);
  });

  it("On-time unstake within grace: gives reward + mints NFTs", async function () {
    const duration = 3;
    const amount = parseUnits("20", DECIMALS);

    await token.connect(user).approve(staking.target, amount);
    await staking.connect(user).stakeTokensFor(user.address, amount, duration);

    // warp на requiredTime + 5s
    const required = BigInt(duration) * BigInt(30 * 24 * 3600);
    await warp(Number(required + 5n));

    // snapshot
    const balBefore = await token.balanceOf(user.address);
    const treasBefore = await token.balanceOf(treasury.address);
    const nftBefore = await discount.balanceOf(user.address);

    // unstake
    await staking.connect(user).unstakeTokensFor(user.address, 0);

    // reward = amount * 5% (getRewardPercentage(3) == 5)
    const reward = amount * 5n / 100n;
    const expectedPayout = amount + reward;

    const balAfter = await token.balanceOf(user.address);
    expect(balAfter - balBefore).to.equal(expectedPayout);

    // treasury потеряла reward
    const treasAfter = await token.balanceOf(treasury.address);
    expect(treasBefore - treasAfter).to.equal(reward);

    // чеканится 2 NFT
    const nftAfter = await discount.balanceOf(user.address);
    expect(nftAfter - nftBefore).to.equal(2n);
  });

  it("Expired unstake: sends full principal to treasury, user gets nothing", async function () {
    const duration = 3;
    const amount = parseUnits("30", DECIMALS);

    await token.connect(user).approve(staking.target, amount);
    await staking.connect(user).stakeTokensFor(user.address, amount, duration);

    // warp за пределы requiredTime + GRACE_PERIOD
    const expire = BigInt(duration) * BigInt(30 * 24 * 3600) + BigInt(180 * 24 * 3600);
    await warp(Number(expire + 10n));

    const balBefore = await token.balanceOf(user.address);
    const treasBefore = await token.balanceOf(treasury.address);

    await staking.connect(user).unstakeTokensFor(user.address, 0);

    // пользователь ничего не получает
    const balAfter = await token.balanceOf(user.address);
    expect(balAfter).to.equal(balBefore);

    // весь principal ушёл в казну
    const treasAfter = await token.balanceOf(treasury.address);
    expect(treasAfter - treasBefore).to.equal(amount);
  });
});
