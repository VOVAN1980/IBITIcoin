const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("StakingModule — extra coverage", function () {
  let staking, token, nftDiscount;
  let owner, alice, bob;

  beforeEach(async () => {
    [owner, alice, bob] = await ethers.getSigners();

    // Деплой NFTDiscount
    const NFTD = await ethers.getContractFactory("NFTDiscount");
    nftDiscount = await NFTD.deploy();
    await nftDiscount.waitForDeployment();

    // Деплой ERC20Mock с начальными токенами у alice
    const ERC20Mock = await ethers.getContractFactory("ERC20Mock");
    token = await ERC20Mock.deploy(
      "TK",
      "TK",
      alice.address,
      ethers.parseEther("1000")
    );
    await token.waitForDeployment();

    // Деплой StakingModule
    const SM = await ethers.getContractFactory("StakingModule");
    staking = await SM.deploy(token.target, nftDiscount.target);
    await staking.waitForDeployment();

    // Устанавливаем treasury, чтобы unstake не падал на отсутствие казны
    await staking.setTreasury(bob.address);
  });

  describe("Pause / Unpause", function () {
    it("pause blocks stake and unstake", async () => {
      // Ставим контракт на паузу
      await staking.pause();

      // Попытка застейкать должна откатиться с "Pausable: paused"
      await token.connect(alice).approve(staking.target, ethers.parseEther("10"));
      await expect(
        staking.connect(alice).stakeTokensFor(alice.address, ethers.parseEther("10"), 3)
      ).to.be.revertedWith("Pausable: paused");

      // Попытка разстейкать тоже должна откатиться
      await expect(
        staking.connect(alice).unstakeTokensFor(alice.address, 0)
      ).to.be.revertedWith("Pausable: paused");

      // Снимаем паузу
      await staking.unpause();

      // После unpause стейкинг снова работает
      await token.connect(alice).approve(staking.target, ethers.parseEther("10"));
      await expect(
        staking.connect(alice).stakeTokensFor(alice.address, ethers.parseEther("10"), 3)
      )
        .to.emit(staking, "Staked")
        .withArgs(alice.address, ethers.parseEther("10"), 3);
    });
  });
});
