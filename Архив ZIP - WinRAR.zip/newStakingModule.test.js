const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("New StakingModule Tests", function () {
  let token, nftDiscount, stakingModule;
  let owner, user;
  const initialSupply = ethers.parseUnits("1000000", 8); // 1,000,000 IBITIcoin (8 decimals)

  beforeEach(async function () {
    [owner, user] = await ethers.getSigners();

    // Deploy ERC20Mock
    const ERC20Mock = await ethers.getContractFactory("ERC20Mock");
    token = await ERC20Mock.deploy("IBITIcoin", "IBITI", owner.address, initialSupply);
    await token.waitForDeployment();

    // Deploy NFTDiscount
    const NFTDiscount = await ethers.getContractFactory("NFTDiscount");
    nftDiscount = await NFTDiscount.deploy();
    await nftDiscount.waitForDeployment();

    // Deploy StakingModule with token and nftDiscount addresses
    const StakingModule = await ethers.getContractFactory("StakingModule");
    stakingModule = await StakingModule.deploy(token.target, nftDiscount.target);
    await stakingModule.waitForDeployment();

    // Передаем токены пользователю и даем разрешение
    const userTokens = ethers.parseUnits("10000", 8);
    await token.transfer(user.address, userTokens);
    await token.connect(user).approve(stakingModule.target, userTokens);

    // Устанавливаем treasury (казну) и разрешенного вызывающего для стейкинга
    // Для остальных тестов treasury установлен, а allowedCaller назначаем как owner
    await stakingModule.connect(owner).setTreasury(owner.address);
    await stakingModule.connect(owner).setAllowedCaller(owner.address);
  });

  it("should allow user to stake tokens and then unstake with reward (on-time)", async function () {
    // Сценарий: Стейк на 1 месяц. Reward для 1-месячного стейка равен 1% от суммы.
    const stakeAmt = ethers.parseUnits("1000", 8);
    const duration = 1; // 1 месяц

    // Стейк токенов
    await expect(
      stakingModule.connect(user).stakeTokensFor(user.address, stakeAmt, duration)
    )
      .to.emit(stakingModule, "Staked")
      .withArgs(user.address, stakeAmt, duration);

    // Переводим время: для стейка на 1 месяц – 30 дней.
    const secondsPerMonth = 30 * 24 * 3600;
    await ethers.provider.send("evm_increaseTime", [secondsPerMonth]);
    await ethers.provider.send("evm_mine", []);

    // Reward для 1-месячного стейка: 1% от 1000 = 10
    const reward = stakeAmt * 1n / 100n;
    const payout = stakeAmt + reward;
    const currentBalance = await token.balanceOf(stakingModule.target);
    if (currentBalance < payout) {
      // Переводим недостающие токены из казны
      await token.transfer(stakingModule.target, payout - currentBalance);
    }

    // Выполняем unstake (индекс 0)
    await expect(
      stakingModule.connect(user).unstakeTokensFor(user.address, 0)
    )
      .to.emit(stakingModule, "Unstaked")
      .withArgs(user.address, stakeAmt, reward, 0, 0, false);

    // Проверяем, что баланс пользователя увеличился
    const finalBalance = await token.balanceOf(user.address);
    expect(finalBalance).to.be.gt(ethers.parseUnits("10000", 8));
  });

  it("should apply penalty on early unstake", async function () {
    const stakeAmt = ethers.parseUnits("1000", 8);
    const duration = 3; // 3 месяца

    // Стейк токенов
    await stakingModule.connect(user).stakeTokensFor(user.address, stakeAmt, duration);

    // Прокручиваем время только 30 дней (ранний вывод)
    const thirtyDays = 30 * 24 * 3600;
    await ethers.provider.send("evm_increaseTime", [thirtyDays]);
    await ethers.provider.send("evm_mine", []);

    // Устанавливаем treasury для штрафов
    await stakingModule.connect(owner).setTreasury(owner.address);

    // Для 3-месячного стейка penalty = stakeAmt * getPenaltyPercentage(3)/100
    const penalty = stakeAmt * 5n / 100n; // если getPenaltyPercentage(3) возвращает 5
    const expectedPayout = stakeAmt - penalty;

    const currBal = await token.balanceOf(stakingModule.target);
    if (currBal < expectedPayout) {
      await token.transfer(stakingModule.target, expectedPayout - currBal);
    }

    const balanceBefore = await token.balanceOf(user.address);
    await expect(
      stakingModule.connect(user).unstakeTokensFor(user.address, 0)
    )
      .to.emit(stakingModule, "Unstaked")
      .withArgs(user.address, stakeAmt, 0, penalty, 0, false);
    const balanceAfter = await token.balanceOf(user.address);
    expect(balanceAfter - balanceBefore).to.equal(expectedPayout);
  });

  it("should revert unstake if treasury is not set", async function () {
    // Создаем новую инстанцию StakingModule без установки treasury.
    const StakingModule = await ethers.getContractFactory("StakingModule");
    const freshStakingModule = await StakingModule.deploy(token.target, nftDiscount.target);
    await freshStakingModule.waitForDeployment();

    // Передаем токены и даем пользователю разрешение
    const userTokens = ethers.parseUnits("5000", 8);
    await token.transfer(user.address, userTokens);
    await token.connect(user).approve(freshStakingModule.target, userTokens);

    // Stake токенов
    const stakeAmt = ethers.parseUnits("1000", 8);
    await freshStakingModule.connect(user).stakeTokensFor(user.address, stakeAmt, 1);

    // Прокручиваем время на 30 дней для 1-месячного стейка.
    const secondsPerMonth = 30 * 24 * 3600;
    await ethers.provider.send("evm_increaseTime", [secondsPerMonth]);
    await ethers.provider.send("evm_mine", []);

    // Так как treasury не установлен (остается address(0)), unstake должен revert.
    await expect(
      freshStakingModule.connect(user).unstakeTokensFor(user.address, 0)
    ).to.be.revertedWith("Treasury not set");
  });
});
