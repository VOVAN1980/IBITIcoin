const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("NFTDiscount – edge coverage (276, 277, 341)", () => {
  let nft, owner, alice;

  before(async () => {
    [owner, alice] = await ethers.getSigners();
    const NFT = await ethers.getContractFactory("NFTDiscount");
    nft = await NFT.deploy();
    await nft.waitForDeployment();
    await nft.setDiscountOperator(owner.address);
  });

  it("should burn expired NFT on useDiscount (lines 276–277)", async () => {
    const uri = "ipfs://expired-uri";
    await nft.mint(alice.address, 1, uri);
    const tokenId = 0;

    // fast-forward > 30 дней
    const block = await ethers.provider.getBlock("latest");
    const expiredTime = block.timestamp + 31 * 24 * 60 * 60;
    await ethers.provider.send("evm_setNextBlockTimestamp", [expiredTime]);
    await ethers.provider.send("evm_mine");

    await nft.useDiscountFor(alice.address, tokenId);

    // Проверка: токен должен быть сожжён
    await expect(nft.ownerOf(tokenId)).to.be.revertedWith("ERC721: invalid token ID");
  });

  it("should revert on duplicate URI in awardVotingRewards (line 341)", async () => {
    const uri = "baseURI://meta/";
    const winner = [owner.address];
    const loser = [];

    // первая выдача пройдёт
    await nft.awardVotingRewards(winner, loser, uri);

    // evm fast-forward на 31 день
    const blockNow = await ethers.provider.getBlock("latest");
    const futureTime = blockNow.timestamp + 31 * 24 * 60 * 60;
    await ethers.provider.send("evm_setNextBlockTimestamp", [futureTime]);
    await ethers.provider.send("evm_mine");

    // повторная попытка вызовет дублирование URI
    await expect(nft.awardVotingRewards(winner, loser, uri))
      .to.be.revertedWith("URI already used");
  });
});
