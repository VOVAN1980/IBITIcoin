const { expect } = require("chai");
const { ethers } = require("hardhat");
const { anyValue } = require("@nomicfoundation/hardhat-chai-matchers/withArgs");

// Вспомогательная функция для логирования адресов
function getAddress(contractInstance) {
  return contractInstance.address || contractInstance.target || "0x0000000000000000000000000000000000000000";
}
function checkAddress(contractName, contractInstance) {
  const addr = getAddress(contractInstance);
  if (!addr || addr === "0x0000000000000000000000000000000000000000") {
    console.error(`${contractName} has a null or zero address: ${addr}`);
  } else {
    console.log(`${contractName} address: ${addr}`);
  }
}

describe("NFTSaleManager — extra coverage", function () {
  let nftSaleManager, nftDiscount;
  let ibitiToken, usdtToken;
  let priceOracle, pool;
  let owner, buyer;

  beforeEach(async function () {
    [owner, buyer] = await ethers.getSigners();

    // 1. Деплой NFTDiscount
    const NFTDiscount = await ethers.getContractFactory("NFTDiscount");
    nftDiscount = await NFTDiscount.deploy();
    await nftDiscount.waitForDeployment();
    checkAddress("NFTDiscount", nftDiscount);

    // 2. Деплой IBITI токена (8 дец.)
    const ERC20Mock = await ethers.getContractFactory("ERC20Mock");
    ibitiToken = await ERC20Mock.deploy("IBITI", "IBI", owner.address, ethers.parseUnits("10000000", 8));
    await ibitiToken.waitForDeployment();
    checkAddress("IBITI Token", ibitiToken);

    // 3. Деплой USDT токена (8 дец.)
    usdtToken = await ERC20Mock.deploy("USDT", "USDT", owner.address, ethers.parseUnits("10000000", 8));
    await usdtToken.waitForDeployment();
    checkAddress("USDT Token", usdtToken);

    // 4. Деплой VolumeWeightedOracle (8 дец.)
    const VolumeWeightedOracle = await ethers.getContractFactory("VolumeWeightedOracle");
    priceOracle = await VolumeWeightedOracle.deploy(8);
    await priceOracle.waitForDeployment();
    checkAddress("VolumeWeightedOracle", priceOracle);

    // 5. Деплой MockUniswapV2Pair и добавляем в оракул
    const MockUniswapV2Pair = await ethers.getContractFactory("MockUniswapV2Pair");
    pool = await MockUniswapV2Pair.deploy(1_000_000, 2000 * 1e6);
    await pool.waitForDeployment();
    checkAddress("MockUniswapV2Pair", pool);
    await priceOracle.connect(owner).addPool(pool.target);

    // 6. Деплой NFTSaleManager
    const NFTSaleManager = await ethers.getContractFactory("NFTSaleManager");
    nftSaleManager = await NFTSaleManager.deploy(
      nftDiscount.target,
      ibitiToken.target,
      usdtToken.target,
      priceOracle.target
    );
    await nftSaleManager.waitForDeployment();
    checkAddress("NFTSaleManager", nftSaleManager);

    // 7. Даем право чеканить NFTSaleManager
    await nftDiscount.connect(owner).setDAOModule(nftSaleManager.target);

    // 8. Устанавливаем цену NFT для discountPercent = 5 (500 центов = $5.00)
    await nftSaleManager.connect(owner).setNFTPrice(5, 500);

    // 9. Переводим и даем allowance покупателю
    await ibitiToken.transfer(buyer.address, ethers.parseUnits("1000", 8));
    await ibitiToken.connect(buyer).approve(nftSaleManager.target, ethers.parseUnits("1000", 8));
    await usdtToken.transfer(buyer.address, ethers.parseUnits("1000", 8));
    await usdtToken.connect(buyer).approve(nftSaleManager.target, ethers.parseUnits("1000", 8));
  });

  describe("Buy NFT with IBITI", function () {
    it("should revert buyNFTWithIBITI when price not set", async function () {
      // Сбрасываем цену
      await nftSaleManager.connect(owner).setNFTPrice(10, 0);
      await expect(
        nftSaleManager.connect(buyer).buyNFTWithIBITI(10, "ipfs://someURI")
      ).to.be.revertedWith("Price not set");
    });

    it("should allow buyNFTWithIBITI at correct rate and mint NFT", async function () {
      // Для discountPercent = 5, ценаUSD = 500 центов.
      // currentPrice = (reserve1 * 10^8) / reserve0 = (2000e6 * 1e8) / 1e6 = 2000e8.
      // ibitiAmount = (500 * 1e14) / (2000 * 1e8) = 250000.
      const expectedIBITIAmount = 250000;

      await expect(nftSaleManager.connect(buyer).buyNFTWithIBITI(5, "ipfs://uniqueURI1"))
        .to.emit(nftSaleManager, "NFTPurchased")
        .withArgs(buyer.address, anyValue, anyValue, ibitiToken.target);

      const current = await nftSaleManager.getCurrentIBITIPrice(5);
      expect(current).to.equal(expectedIBITIAmount);
    });
  });

  describe("Buy NFT with USDT", function () {
    it("should revert buyNFTWithUSDT when price not set", async function () {
      // Сбрасываем цену через setNFTPrice
      await nftSaleManager.connect(owner).setNFTPrice(5, 0);
      await expect(
        nftSaleManager.connect(buyer).buyNFTWithUSDT(5, "ipfs://someURI")
      ).to.be.revertedWith("Price not set");
    });

    it("should allow buyNFTWithUSDT at correct rate and mint NFT", async function () {
      // Для discountPercent = 5, priceUSD = 500 центов.
      // getCurrentUSDTPrice = 500 * 10^(8-2) = 500 * 1e6 = 500_000_000.
      const expectedUSDTAmount = 500000000;
      const current = await nftSaleManager.getCurrentUSDTPrice(5);
      expect(current).to.equal(expectedUSDTAmount);

      await expect(nftSaleManager.connect(buyer).buyNFTWithUSDT(5, "ipfs://uniqueURI2"))
        .to.emit(nftSaleManager, "NFTPurchased")
        .withArgs(buyer.address, anyValue, anyValue, usdtToken.target);
    });
  });

  describe("Get current prices", function () {
    it("should return correct current prices for IBITI and USDT", async function () {
      expect(await nftSaleManager.getCurrentIBITIPrice(5)).to.equal(250000);
      expect(await nftSaleManager.getCurrentUSDTPrice(5)).to.equal(500000000);
    });
  });
});
