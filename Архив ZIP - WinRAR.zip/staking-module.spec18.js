const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("StakingModule - stake/unstake behavior", function () {
  const DECIMALS = 18;
  const MONTH    = 30 * 24 * 60 * 60;       // 1 месяц
  const GRACE    = 180 * 24 * 60 * 60;      // 180 дней

  let owner, user, treasury;
  let token, nft, staking;

  beforeEach(async () => {
    [owner, user, treasury] = await ethers.getSigners();

    const ERC20Mock = await ethers.getContractFactory("ERC20Mock");
    token = await ERC20Mock.deploy(
      "MockToken",
      "MTK",
      owner.address,
      ethers.parseUnits("1000000", DECIMALS)  // исправлено: убрали подчёркивание
    );
    await token.waitForDeployment();

    const NFTDiscount = await ethers.getContractFactory("NFTDiscount");
    nft = await NFTDiscount.deploy();
    await nft.waitForDeployment();

    const StakingModule = await ethers.getContractFactory("StakingModule");
    staking = await StakingModule.deploy(token.target, nft.target);
    await staking.waitForDeployment();

    // Настройка
    await nft.setIbitiToken(token.target);
    await nft.setPayToken(token.target);
    await nft.setStakingModule(staking.target);
    await nft.setJackpotMinter(owner.address, true);
    await staking.setTreasury(treasury.address);
    await staking.setAllowedCaller(owner.address);
    await staking.setRewardConfig(3, 2, 5);
    await staking.setRewardConfig(6, 3, 10);

    // Раздаём пользователю и казне по 1000 токенов
    await token.transfer(user.address, ethers.parseUnits("1000", DECIMALS));
    await token.transfer(treasury.address, ethers.parseUnits("1000", DECIMALS));
  });

  it("should charge penalty and return reduced amount when unstaked early", async () => {
  const amount = ethers.parseUnits("100", DECIMALS);

  // Stake 100 tokens for 6 months
  await token.connect(user).approve(staking, amount);
  await staking.connect(user).stakeTokensFor(user.address, amount, 6);

  // Fast‐forward 1 month (early unstake)
  await ethers.provider.send("evm_increaseTime", [MONTH]);
  await ethers.provider.send("evm_mine");

  // Calculate 12% penalty and fund contract with principal + penalty
  const penalty        = amount * 12n / 100n;       // 12 tokens
  const fundingAmount  = amount + penalty;         // 112 tokens
  await token.transfer(staking.target, fundingAmount);

  // Save balances before unstake
  const balUserBefore    = await token.balanceOf(user.address);
  const balTreasuryBefore = await token.balanceOf(treasury.address);

  // Unstake
  await staking.connect(user).unstakeTokensFor(user.address, 0);

  // Save balances after
  const balUserAfter     = await token.balanceOf(user.address);
  const balTreasuryAfter = await token.balanceOf(treasury.address);

  // 1) Пользователь получил principal – penalty (100 – 12 = 88)
  const expectedReturn = amount - penalty;
  expect(balUserAfter - balUserBefore).to.equal(expectedReturn);

  // 2) Баланс казны не изменился (штраф остался в контракте)
  expect(balTreasuryAfter).to.equal(balTreasuryBefore);
});

  it("should mint NFTs and apply reward when unstaked during grace period", async () => {
    const amount = ethers.parseUnits("100", DECIMALS);

    await token.connect(user).approve(staking, amount);
    await staking.connect(user).stakeTokensFor(user.address, amount, 3);

    // Переносим время на 3 мес. + 60 сек.
    await ethers.provider.send("evm_increaseTime", [3 * MONTH + 60]);
    await ethers.provider.send("evm_mine");

    // Выплата = principal + 5%
    const totalReturn = amount + (amount * 5n / 100n);
    await token.transfer(staking.target, totalReturn);

    const balBefore = await token.balanceOf(user.address);
    await staking.connect(user).unstakeTokensFor(user.address, 0);
    const balAfter  = await token.balanceOf(user.address);

    const expectedReward = amount * 5n / 100n;
    expect(balAfter - balBefore).to.equal(amount + expectedReward);
    expect(await nft.balanceOf(user.address)).to.equal(2);
  });

  it("should send all to treasury if unstaked after grace period", async () => {
    const amount = ethers.parseUnits("100", DECIMALS);

    await token.connect(user).approve(staking, amount);
    await staking.connect(user).stakeTokensFor(user.address, amount, 3);

    // Переносим время на 3 мес. + 180 дней + 1 сек.
    await ethers.provider.send("evm_increaseTime", [3 * MONTH + GRACE + 1]);
    await ethers.provider.send("evm_mine");

    const balUserBefore  = await token.balanceOf(user.address);
    const balTreasBefore = await token.balanceOf(treasury.address);

    await staking.connect(user).unstakeTokensFor(user.address, 0);

    const balUserAfter  = await token.balanceOf(user.address);
    const balTreasAfter = await token.balanceOf(treasury.address);

    expect(balUserAfter - balUserBefore).to.equal(0n);
    expect(balTreasAfter - balTreasBefore).to.equal(amount);
  });

  it("should revert when staking with unknown duration", async () => {
    const amount = ethers.parseUnits("100", DECIMALS);
    await token.connect(user).approve(staking, amount);

    await expect(
      staking.connect(user).stakeTokensFor(user.address, amount, 13)
    ).to.be.revertedWith("Invalid duration");
  });
});
