const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("StakingModule — reentrancy protection", function () {
  let owner, attacker;
  let staking, malicious;

  // Ставим 10 токенов в качестве объёма атаки
  const STAKE_AMOUNT = ethers.parseUnits("10", 18);

  beforeEach(async () => {
    [owner, attacker] = await ethers.getSigners();

    // 1) Деплой MaliciousToken от имени attacker — в конструкторе ему заминтится 1000 MAL
    const Malicious = await ethers.getContractFactory("MaliciousToken");
    malicious = await Malicious.connect(attacker).deploy(ethers.ZeroAddress);
    await malicious.waitForDeployment();

    // 2) Деплой NFTDiscount (пустой, нужен для конструктора)
    const NFTDiscount = await ethers.getContractFactory("NFTDiscount");
    const nftDiscount = await NFTDiscount.deploy();
    await nftDiscount.waitForDeployment();

    // 3) Деплой StakingModule с malicious как токеном
    const Staking = await ethers.getContractFactory("StakingModule");
    staking = await Staking.connect(owner).deploy(malicious.target, nftDiscount.target);
    await staking.waitForDeployment();

    // 4) Настраиваем staking в malicious, чтобы transferFrom звал unstakeTokens()
    await malicious.connect(attacker).setStaking(staking.target);

    // 5) approve стейкингу списывать MAL у attacker
    await malicious.connect(attacker).approve(staking.target, STAKE_AMOUNT);

    // 6) Настраиваем treasury и allowedCaller, хотя для stakeTokensFor это не обязательно
    await staking.connect(owner).setTreasury(owner.address);
    await staking.connect(owner).setAllowedCaller(owner.address);
  });

  it("should block reentrant stakeTokensFor via malicious token", async function () {
    // При первом вызове transferFrom malicious попытается вызвать staking.unstakeTokens()
    // но ReentrancyGuard в stakeTokensFor предотвратит повторный вход
    await expect(
      staking.connect(attacker).stakeTokensFor(
        attacker.address,
        STAKE_AMOUNT,
        1 // duration in months
      )
    ).to.be.revertedWith("ReentrancyGuard: reentrant call");
  });
});
