const { expect } = require("chai");
const { ethers } = require("hardhat");
const { time } = require("@nomicfoundation/hardhat-network-helpers");

describe("StakingModule Coverage Tests", function () {
  let token, nftDiscount, staking, owner, user, treasury, stranger;

  beforeEach(async function () {
    [owner, user, treasury, stranger] = await ethers.getSigners();

    // Deploy mock token
    const Token = await ethers.getContractFactory("ERC20MintableMock");
    token = await Token.deploy("Mock Token", "MTKN");
    await token.mint(owner.address, ethers.parseUnits("1000000", 8));

    // Deploy mock NFT
    const NFTMock = await ethers.getContractFactory("MockNFTDiscount");
    nftDiscount = await NFTMock.deploy();

    // Deploy staking module
    const StakingModule = await ethers.getContractFactory("StakingModule");
    staking = await StakingModule.deploy(token.target, nftDiscount.target);

    // Set treasury
    await staking.setTreasury(treasury.address);

    // Approve and stake
    await token.approve(staking.target, ethers.MaxUint256);
    await staking.stakeTokensFor(owner.address, ethers.parseUnits("1000", 8), 1); // 1 month
  });

  it("should apply penalty on early unstake [line 297]", async () => {
    await time.increase(3600); // 1 hour
    await staking.unstakeTokensFor(owner.address, 0);
    const contractBal = await token.balanceOf(staking.target);
    expect(contractBal).to.be.gt(0);
  });

  it("should reward on timely unstake and mint NFT [line 305]", async () => {
    await time.increase(31 * 24 * 60 * 60); // > 1 month
    await token.mint(treasury.address, ethers.parseUnits("10000", 8));
    await token.connect(treasury).approve(staking.target, ethers.MaxUint256);
    await staking.unstakeTokensFor(owner.address, 0);
    expect(await token.balanceOf(staking.target)).to.equal(0);
  });

  it("should send all to treasury on overdue unstake [line 323]", async () => {
    await time.increase(210 * 24 * 60 * 60); // > 1 month + grace
    const before = await token.balanceOf(treasury.address);
    await staking.unstakeTokensFor(owner.address, 0);
    const after = await token.balanceOf(treasury.address);
    expect(after).to.be.gt(before);
  });

  it("should skim excess to treasury", async () => {
    await time.increase(3600);
    await staking.unstakeTokensFor(owner.address, 0);

    const totalStaked = await staking.totalStaked();
    const currentBalance = await token.balanceOf(staking.target);
    const excess = currentBalance - totalStaked;

    const before = await token.balanceOf(treasury.address);
    await staking.skimExcessToTreasury(excess);
    const after = await token.balanceOf(treasury.address);
    expect(after).to.be.gt(before);
  });

  it("should rescue tokens except core staking token", async () => {
    const ERC20 = await ethers.getContractFactory("ERC20MintableMock");
    const otherToken = await ERC20.deploy("RescueMe", "RSQ");
    await otherToken.mint(staking.target, ethers.parseUnits("123", 8));

    const before = await otherToken.balanceOf(owner.address);
    await staking.rescueTokens(otherToken.target, owner.address, ethers.parseUnits("100", 8));
    const after = await otherToken.balanceOf(owner.address);
    expect(after - before).to.equal(ethers.parseUnits("100", 8));
  });

  it("should revert if trying to rescue core token", async () => {
    await expect(
      staking.rescueTokens(token.target, owner.address, 1)
    ).to.be.revertedWith("Use skimExcess");
  });

    it("should allow whitelisted caller to stake/unstake", async () => {
  await staking.setAllowedCaller(user.address); // разрешаем user'у вызывать stake/unstake

  const userAmount = ethers.parseUnits("100", 8);
  await token.connect(user).mint(user.address, userAmount);
  await token.connect(user).approve(staking.target, userAmount);

  // создаём стейк → индекс будет 0
  await staking.connect(user).stakeTokensFor(user.address, userAmount, 1);

  await time.increase(31 * 24 * 60 * 60); // ждём месяц

  await token.mint(treasury.address, ethers.parseUnits("10000", 8));
  await token.connect(treasury).approve(staking.target, ethers.MaxUint256);

  // используем индекс 0
  await staking.connect(user).unstakeTokensFor(user.address, 0);
  expect(await token.balanceOf(user.address)).to.be.gt(0);
});

  it("should revert for non-whitelisted caller", async () => {
    await expect(
      staking.connect(stranger).stakeTokensFor(user.address, 1, 1)
    ).to.be.revertedWith("Only staker or token");
  });
});
