const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("StakingModule – full coverage", function () {
  let owner, alice, bob;
  let token, discount, staking;
  const ONE_TOKEN    = ethers.parseUnits("1000", 8);
  const STAKE_AMOUNT = ethers.parseUnits("100", 8);

  beforeEach(async function () {
    [owner, alice, bob] = await ethers.getSigners();

    // Deploy ERC20Mock as staking token
    const ERC20Mock = await ethers.getContractFactory("ERC20Mock");
    token = await ERC20Mock.deploy(
      "MockToken", "MCK", owner.address,
      ethers.parseUnits("1000000", 8)
    );
    await token.waitForDeployment();

    // Deploy NFTDiscount for staking rewards
    const Discount = await ethers.getContractFactory("NFTDiscount");
    discount = await Discount.deploy();
    await discount.waitForDeployment();

    // Deploy StakingModule
    const Staking = await ethers.getContractFactory("StakingModule");
    staking = await Staking.deploy(token.target, discount.target);
    await staking.waitForDeployment();

    // Distribute tokens and approve staking contract
    await token.connect(owner).transfer(alice.address, ONE_TOKEN);
    await token.connect(owner).transfer(bob.address,   ONE_TOKEN);
    await token.connect(alice).approve(staking.target, ONE_TOKEN);
    await token.connect(bob).approve(staking.target,   ONE_TOKEN);
  });

  it("allows staking when not paused and increments stake count", async function () {
    expect(await staking.getStakeCount(alice.address)).to.equal(0);
    await staking.connect(alice).stakeTokensFor(alice.address, STAKE_AMOUNT, 6);
    expect(await staking.getStakeCount(alice.address)).to.equal(1);
  });

  it("reverts staking zero amount", async function () {
    await expect(
      staking.connect(alice).stakeTokensFor(alice.address, 0n, 6)
    ).to.be.revertedWith("Amount zero");
  });

  it("enforces pause and unpause by owner", async function () {
    await staking.pause();
    await expect(
      staking.connect(alice).stakeTokensFor(alice.address, STAKE_AMOUNT, 6)
    ).to.be.revertedWith("Pausable: paused");

    await staking.unpause();
    await staking.connect(alice).stakeTokensFor(alice.address, STAKE_AMOUNT, 6);
    expect(await staking.getStakeCount(alice.address)).to.equal(1);
  });

  it("reverts unstake with bad index", async function () {
    // Set treasury to allow unstaking
    await staking.setTreasury(owner.address);
    await staking.connect(alice).stakeTokensFor(alice.address, STAKE_AMOUNT, 3);
    await expect(
      staking.connect(alice).unstakeTokensFor(alice.address, 1)
    ).to.be.revertedWith("Bad index");
  });

  it("allows emergencyUnstake returning only principal", async function () {
    await staking.connect(alice).stakeTokensFor(alice.address, STAKE_AMOUNT, 3);
    // Pause to enable emergency unstake
    await staking.pause();
    const balBefore = await token.balanceOf(alice.address);
    await staking.connect(alice).emergencyUnstake(0);
    expect(await staking.getStakeCount(alice.address)).to.equal(0);
    expect(await token.balanceOf(alice.address)).to.equal(balBefore + STAKE_AMOUNT);
  });
});
