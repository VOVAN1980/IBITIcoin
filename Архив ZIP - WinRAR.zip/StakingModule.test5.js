const { expect } = require("chai");
const { ethers, network } = require("hardhat");
const { anyValue } = require("@nomicfoundation/hardhat-chai-matchers/withArgs");

describe("StakingModule", function () {
  let token, nftDiscount, staking, owner, user, treasury, allowedCaller;
  const MONTH = 30 * 24 * 3600;
  const GRACE = 180 * 24 * 3600;

  beforeEach(async () => {
    [owner, user, treasury, allowedCaller] = await ethers.getSigners();

    const ERC20Mock = await ethers.getContractFactory("ERC20Mock");
    token = await ERC20Mock.deploy("TKN", "TKN", owner.address, ethers.parseUnits("10000", 8));

    await token.transfer(user.address, ethers.parseUnits("1000", 8));
    await token.transfer(treasury.address, ethers.parseUnits("1000", 8));

    const NFTDiscount = await ethers.getContractFactory("NFTDiscount");
    nftDiscount = await NFTDiscount.deploy();

    const StakingModule = await ethers.getContractFactory("StakingModule");
    staking = await StakingModule.deploy(token.target, nftDiscount.target);

    await nftDiscount.setDAOModule(staking.target);
    await staking.setTreasury(treasury.address);
    await staking.setAllowedCaller(allowedCaller.address);

    await token.connect(treasury).approve(staking.target, ethers.parseUnits("1000", 8));
    await token.connect(user).approve(staking.target, ethers.parseUnits("1000", 8));
  });

  it("stakeTokensFor: обычный стейк от пользователя", async () => {
    await expect(
      staking.connect(user).stakeTokensFor(user.address, ethers.parseUnits("100", 8), 3)
    )
      .to.emit(staking, "Staked")
      .withArgs(user.address, ethers.parseUnits("100", 8), 3);
  });

  it("stakeTokensFor: может вызывать allowedCaller", async () => {
    await expect(
      staking.connect(allowedCaller).stakeTokensFor(user.address, ethers.parseUnits("50", 8), 2)
    ).to.emit(staking, "Staked");
  });

  it("pause/unpause запрещают/разрешают стейк", async () => {
    await staking.connect(owner).pause();
    await expect(
      staking.connect(user).stakeTokensFor(user.address, 1, 1)
    ).to.be.revertedWith("Pausable: paused");

    await staking.connect(owner).unpause();
    await expect(
      staking.connect(user).stakeTokensFor(user.address, 1, 1)
    ).to.emit(staking, "Staked");
  });

  it("setRewardConfig: запрещает неверную длительность", async () => {
    await expect(
      staking.connect(owner).setRewardConfig(0, 1, 1)
    ).to.be.revertedWith("Bad duration");
    await expect(
      staking.connect(owner).setRewardConfig(13, 1, 1)
    ).to.be.revertedWith("Bad duration");
  });

  it("autoReplenish вызывается при нехватке баланса", async () => {
    const amt = ethers.parseUnits("50", 8);
    await staking.connect(user).stakeTokensFor(user.address, amt, 3);

    await network.provider.send("evm_increaseTime", [3 * MONTH + 1]);
    await network.provider.send("evm_mine");

    await token.connect(owner).transfer(owner.address, await token.balanceOf(staking.target));

    await expect(staking.connect(user).unstakeTokens())
      .to.emit(staking, "Unstaked");
  });

  it("getPenaltyPercentage и getRewardPercentage покрыты", async () => {
    for (let m = 1; m <= 12; m++) {
      const p = await staking.getPenaltyPercentage(m);
      const r = await staking.getRewardPercentage(m);
      expect(typeof p).to.equal("bigint");
      expect(typeof r).to.equal("bigint");
    }
  });

  describe("unstakeTokens (early, grace, expired)", () => {
    const amt = ethers.parseUnits("100", 8);

    beforeEach(async () => {
      await staking.connect(user).stakeTokensFor(user.address, amt, 6);
    });

    it("ранний unstake (elapsed < duration): penalty applied, reward = 0", async () => {
      await network.provider.send("evm_increaseTime", [3 * MONTH]);
      await network.provider.send("evm_mine");

      await expect(staking.connect(user).unstakeTokens())
        .to.emit(staking, "Unstaked")
        .withArgs(user.address, amt, 0, anyValue, 0, false);
    });

    it("unstake в grace period: reward + NFT", async () => {
      await network.provider.send("evm_increaseTime", [6 * MONTH + MONTH]);
      await network.provider.send("evm_mine");

      await expect(staking.connect(user).unstakeTokens())
        .to.emit(staking, "Unstaked")
        .withArgs(user.address, amt, anyValue, 0, 2, false);
    });

    it("expired unstake (elapsed > duration+grace): principal → treasury", async () => {
      await network.provider.send("evm_increaseTime", [6 * MONTH + GRACE + 1]);
      await network.provider.send("evm_mine");

      await expect(staking.connect(user).unstakeTokens())
        .to.emit(staking, "Unstaked")
        .withArgs(user.address, amt, 0, 0, 0, true);
    });
  });
});
