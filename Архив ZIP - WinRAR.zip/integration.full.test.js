const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("Full Integration – NFTDiscount → StakingModule → Reward NFT", function () {
  let deployer, treasury, user;
  let token, discount, staking;
  const DECIMALS = 8;
  const { parseUnits } = ethers;

  beforeEach(async function () {
    [deployer, treasury, user] = await ethers.getSigners();

    // Deploy ERC20Mock with 8 decimals
    const ERC20Mock = await ethers.getContractFactory("ERC20Mock");
    token = await ERC20Mock.deploy(
      "Test Token",
      "TST",
      deployer.address,
      parseUnits("2000", DECIMALS)
    );
    await token.waitForDeployment();

    // Deploy NFTDiscount
    const NFTDiscountCF = await ethers.getContractFactory("NFTDiscount");
    discount = await NFTDiscountCF.deploy();
    await discount.waitForDeployment();

    // Deploy StakingModule(token, discount)
    const StakingModuleCF = await ethers.getContractFactory("StakingModule");
    staking = await StakingModuleCF.deploy(token.target, discount.target);
    await staking.waitForDeployment();

    // Authorize & configure
    await discount.connect(deployer).setDAOModule(staking.target);
    await staking.connect(deployer).setTreasury(treasury.address);
    await staking.connect(deployer).setRewardConfig(1, 1, 5);

    // Fund treasury and user
    await token.connect(deployer).transfer(treasury.address, parseUnits("800", DECIMALS));
    await token.connect(treasury).approve(staking.target, ethers.MaxUint256);
    await token.connect(deployer).transfer(user.address, parseUnits("100", DECIMALS));

    // Mint a discount NFT for user
    await discount.connect(deployer).mint(user.address, 10, "ipfs://test-nft-uri");
  });

  it("user stakes 1 month and receives principal, reward, and bonus NFT", async function () {
    const stakeAmount = parseUnits("10", DECIMALS);

    // 1) Проверяем начальный баланс
    const initialBal = await token.balanceOf(user.address);
    expect(initialBal).to.equal(parseUnits("100", DECIMALS));

    // 2) Стейкаем
    await token.connect(user).approve(staking.target, stakeAmount);
    await staking.connect(user).stakeTokensFor(user.address, stakeAmount, 1);
    expect(await token.balanceOf(user.address)).to.equal(initialBal - stakeAmount);

    // 3) Время +31 день
    await ethers.provider.send("evm_increaseTime", [31 * 24 * 3600]);
    await ethers.provider.send("evm_mine", []);

    // 4) Снэпшоты перед анстейком
    const nftBefore = await discount.balanceOf(user.address);
    const balBefore = await token.balanceOf(user.address);

    // 5) Анстейк
    await staking.connect(user).unstakeTokensFor(user.address, 0);
    const balAfter = await token.balanceOf(user.address);

    // 6) Ожидаемое вознаграждение и сумма
    const expectedReward = parseUnits("0.1", DECIMALS);       // 0.1 токена
    const expectedTotal = stakeAmount + expectedReward;       // 10 + 0.1

    // 7) Проверки: principal + reward
    expect(balAfter - balBefore).to.equal(expectedTotal);
    expect(await token.balanceOf(user.address)).to.equal(balBefore + expectedTotal);

    // 8) Бонусный NFT
    expect(await discount.balanceOf(user.address)).to.equal(nftBefore + 1n);
  });
});
