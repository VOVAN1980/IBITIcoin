const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("IBITIcoin — extra coverage", function () {
  let owner, alice, bob;
  let paymentToken, feeManager;
  let userStatusManager, bridgeManager;
  let nftDiscount, stakingModule;
  let IBITI, ibiti;

  beforeEach(async function () {
    [owner, alice, bob] = await ethers.getSigners();

    // 1. ERC20 for payments
    const ERC20Mock = await ethers.getContractFactory("ERC20Mock");
    paymentToken = await ERC20Mock.deploy(
      "PayToken", "PTK",
      owner.address,
      ethers.parseEther("1000")
    );
    await paymentToken.waitForDeployment();

    // 2. FeeManager
    const FeeManager = await ethers.getContractFactory("FeeManager");
    feeManager = await FeeManager.deploy(paymentToken.target);
    await feeManager.waitForDeployment();

    // 3. UserStatusManager
    const USM = await ethers.getContractFactory("UserStatusManager");
    userStatusManager = await USM.deploy();
    await userStatusManager.waitForDeployment();

    // 4. BridgeManager
    const BM = await ethers.getContractFactory("BridgeManager");
    bridgeManager = await BM.deploy();
    await bridgeManager.waitForDeployment();

    // 5. NFTDiscount
    const NFTDiscount = await ethers.getContractFactory("NFTDiscount");
    nftDiscount = await NFTDiscount.deploy();
    await nftDiscount.waitForDeployment();

    // 6. StakingModule
    const StakingModule = await ethers.getContractFactory("StakingModule");
    stakingModule = await StakingModule.deploy(
      paymentToken.target,
      nftDiscount.target
    );
    await stakingModule.waitForDeployment();

    // fund Alice for staking
    await paymentToken.transfer(alice.address, ethers.parseUnits("100", 8));
    await paymentToken.connect(alice).approve(
      stakingModule.target,
      ethers.parseUnits("100", 8)
    );

    // 7. Deploy IBITIcoin
    IBITI = await ethers.getContractFactory("IBITIcoin");
    ibiti = await IBITI.deploy(
      "IBITI", "IBI",
      owner.address,
      owner.address,
      feeManager.target,
      userStatusManager.target,
      bridgeManager.target,
      stakingModule.target,
      owner.address // daoModule stub
    );
    await ibiti.waitForDeployment();

    // link FeeManager and NFTDiscount
    await feeManager.setTokenContract(ibiti.target);
    await ibiti.setNFTDiscount(nftDiscount.target);
  });

  it("stakeTokens does not revert and mints no fees internally", async function () {
    await ibiti.transfer(alice.address, ethers.parseUnits("50", 8));
    await expect(
      stakingModule.connect(alice).stakeTokensFor(
        alice.address,
        ethers.parseUnits("10", 8),
        1
      )
    ).to.not.be.reverted;
  });

  describe("DAO proxy success", function () {
    let mockDAO;
    beforeEach(async function () {
      const MockDAO = await ethers.getContractFactory("MockDAO");
      mockDAO = await MockDAO.deploy();
      await mockDAO.waitForDeployment();

      ibiti = await IBITI.deploy(
        "IBITI", "IBI",
        owner.address,
        owner.address,
        feeManager.target,
        userStatusManager.target,
        bridgeManager.target,
        stakingModule.target,
        mockDAO.target
      );
      await ibiti.waitForDeployment();
      await feeManager.setTokenContract(ibiti.target);
      await ibiti.setNFTDiscount(nftDiscount.target);
    });

    it("createProposalSimple doesn't revert", async function () {
      await expect(ibiti.connect(alice).createProposalSimple("Test"))
        .to.not.be.reverted;
    });

    it("voteProposal doesn't revert", async function () {
      await expect(ibiti.connect(alice).voteProposal(1, true))
        .to.not.be.reverted;
    });

    it("executeProposalSimple doesn't revert", async function () {
      await expect(ibiti.connect(alice).executeProposalSimple(1))
        .to.not.be.reverted;
    });
  });

  describe("Bridge proxy success", function () {
    beforeEach(async function () {
      await bridgeManager.connect(owner).setBridge(ibiti.target, true);
      await bridgeManager.connect(owner).setBridge(alice.address, true);
      const typ = ethers.encodeBytes32String("T");
      await bridgeManager.connect(owner).setBridgeInfo(
        alice.address,
        true,
        true,
        typ,
        ethers.parseUnits("100000", 8),
        "Bridge description"
      );
      await ibiti.connect(owner).transfer(bob.address, ethers.parseUnits("20", 8));
      await ibiti.connect(bob).approve(alice.address, ethers.parseUnits("20", 8));
    });

    it("bridgeMint and bridgeBurn by trusted bridge work correctly", async function () {
      expect(await ibiti.balanceOf(bob.address)).to.equal(ethers.parseUnits("20", 8));
      await ibiti.connect(bob).burn(ethers.parseUnits("2", 8));
      expect(await ibiti.balanceOf(bob.address)).to.equal(ethers.parseUnits("18", 8));
      await expect(
        ibiti.connect(alice).bridgeMint(bob.address, ethers.parseUnits("2", 8))
      ).to.not.be.reverted;
      expect(await ibiti.balanceOf(bob.address)).to.equal(ethers.parseUnits("20", 8));
      await expect(
        ibiti.connect(alice).bridgeBurn(bob.address, ethers.parseUnits("2", 8))
      ).to.not.be.reverted;
      expect(await ibiti.balanceOf(bob.address)).to.equal(ethers.parseUnits("18", 8));
    });
  });

  describe("purchaseCoinBNB — simple", function () {
    beforeEach(async function () {
      await ibiti.connect(owner).setAcceptedPayment(ethers.ZeroAddress, true);
      await ibiti.connect(owner).setCoinPriceBNB(1);
    });

    it("refunds excess BNB", async function () {
      await ibiti.connect(alice).purchaseCoinBNB({ value: 10 });
      expect(await ibiti.balanceOf(alice.address)).to.equal(ethers.parseUnits("10", 8));
    });
  });

  describe("withdrawOwnerFunds", function () {
    beforeEach(async function () {
      await ibiti.connect(owner).setAcceptedPayment(ethers.ZeroAddress, true);
      await ibiti.connect(owner).setCoinPriceBNB(1);
      await ibiti.connect(alice).purchaseCoinBNB({ value: 1 });
    });

    it("withdraws and then reverts when empty", async function () {
      await expect(ibiti.connect(owner).withdrawOwnerFunds()).to.not.be.reverted;
      await expect(ibiti.connect(owner).withdrawOwnerFunds())
        .to.be.reverted;
    });
  });

  describe("admin setters", function () {
    it("setAcceptedPayment & setCoinPriceToken", async function () {
      await expect(ibiti.connect(owner).setAcceptedPayment(paymentToken.target, true))
        .to.not.be.reverted;
      await expect(ibiti.connect(owner).setCoinPriceToken(paymentToken.target, 123))
        .to.not.be.reverted;
    });

    it("setCoinPriceBNB / setUseOracle / setCoinPriceUSD", async function () {
      await expect(ibiti.connect(owner).setCoinPriceBNB(42)).to.not.be.reverted;
      await expect(ibiti.connect(owner).setUseOracle(true)).to.not.be.reverted;
      await expect(ibiti.connect(owner).setCoinPriceUSD(99)).to.not.be.reverted;
    });
  });
});
