const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("VolumeWeightedOracle Tests", function() {
  let oracle, mockPair;
  let owner;
  const decimalsOracle = 8;

  beforeEach(async function() {
    [owner] = await ethers.getSigners();
    const VolumeWeightedOracle = await ethers.getContractFactory("VolumeWeightedOracle");
    oracle = await VolumeWeightedOracle.deploy(decimalsOracle);
    await oracle.waitForDeployment();

    // Deploy mock pair with, например, reserve0 = 1000, reserve1 = 2000.
    const MockUniswapV2Pair = await ethers.getContractFactory("MockUniswapV2Pair");
    mockPair = await MockUniswapV2Pair.deploy(1000, 2000);
    await mockPair.waitForDeployment();

    // Добавляем пул в оракул
    await oracle.connect(owner).addPool(mockPair.target);
  });

  it("should compute price correctly", async function() {
    // Ожидается, что цена = (reserve1 * 10^decimals) / reserve0 = (2000*10^8)/1000 = 2 * 10^8
    const price = await oracle.getPrice();
    expect(price).to.equal(2 * 10**8);
  });

  it("should remove pool and update index", async function() {
    await oracle.connect(owner).removePool(mockPair.target);
    // При удалении пул должен быть удалён, а последующий вызов getPrice вернёт 0.
    const price = await oracle.getPrice();
    expect(price).to.equal(0);
  });
});
