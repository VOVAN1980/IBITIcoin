const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("VolumeWeightedOracle", function () {
  let oracle, owner;
  const DECIMALS = 6;

  beforeEach(async function () {
    [owner] = await ethers.getSigners();
    const Oracle = await ethers.getContractFactory("VolumeWeightedOracle");
    oracle = await Oracle.deploy(DECIMALS);
    await oracle.waitForDeployment();
  });

  it("should start with zero pools and price 0", async function () {
    expect(await oracle.poolCount()).to.equal(0);
    expect(await oracle.getPrice()).to.equal(0);
  });

  it("addPool should emit PoolAdded and increase count", async function () {
    const MockPair = await ethers.getContractFactory("MockUniswapV2Pair");
    const pair = await MockPair.deploy(5, 25);
    await pair.waitForDeployment();

    await expect(oracle.addPool(pair.target))
      .to.emit(oracle, "PoolAdded")
      .withArgs(pair.target);
    expect(await oracle.poolCount()).to.equal(1);
  });

  it("getPrice returns correct price for single pool", async function () {
    // reserves: reserve0=2, reserve1=10 => price = (10 * 10**DECIMALS) / 2
    const MockPair = await ethers.getContractFactory("MockUniswapV2Pair");
    const pair = await MockPair.deploy(2, 10);
    await pair.waitForDeployment();

    await oracle.addPool(pair.target);
    const expected = (10n * 10n ** BigInt(DECIMALS)) / 2n;
    expect(await oracle.getPrice()).to.equal(expected);
  });

  it("skips pools with zero reserves", async function () {
    const MockPair = await ethers.getContractFactory("MockUniswapV2Pair");
    const p1 = await MockPair.deploy(0, 100); // skipped
    const p2 = await MockPair.deploy(10, 50);
    await p1.waitForDeployment();
    await p2.waitForDeployment();

    await oracle.addPool(p1.target);
    await oracle.addPool(p2.target);
    // Only p2 contributes: price = (50 * 10**DECIMALS) / 10
    const expected = (50n * 10n ** BigInt(DECIMALS)) / 10n;
    expect(await oracle.getPrice()).to.equal(expected);
  });

  it("calculates volume-weighted average for multiple pools", async function () {
    const MockPair = await ethers.getContractFactory("MockUniswapV2Pair");
    // pool1: r0=2,r1=10 => price1=5eDEC; weight1=2
    const p1 = await MockPair.deploy(2, 10);
    // pool2: r0=8,r1=32 => price2=4eDEC; weight2=8
    const p2 = await MockPair.deploy(8, 32);
    await p1.waitForDeployment();
    await p2.waitForDeployment();

    await oracle.addPool(p1.target);
    await oracle.addPool(p2.target);

    // weightedSum = price1*2 + price2*8 = 5eDEC*2 + 4eDEC*8 = 10eDEC + 32eDEC = 42eDEC
    // totalWeight = 10 => avg = 4.2eDEC
    const price1 = (10n * 10n ** BigInt(DECIMALS)) / 2n;
    const price2 = (32n * 10n ** BigInt(DECIMALS)) / 8n;
    const weightedSum = price1 * 2n + price2 * 8n;
    const totalWeight = 2n + 8n;
    const expected = weightedSum / totalWeight;

    expect(await oracle.getPrice()).to.equal(expected);
  });

  it("removePool should emit PoolRemoved and decrease count", async function () {
    const MockPair = await ethers.getContractFactory("MockUniswapV2Pair");
    const pair = await MockPair.deploy(3, 15);
    await pair.waitForDeployment();

    await oracle.addPool(pair.target);
    expect(await oracle.poolCount()).to.equal(1);

    await expect(oracle.removePool(pair.target))
      .to.emit(oracle, "PoolRemoved")
      .withArgs(pair.target);
    expect(await oracle.poolCount()).to.equal(0);
  });
});