const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("StakingModule – NFTDiscount and reward minting", function () {
  let owner, user;
  let token, staking, nftDiscount;

  beforeEach(async function () {
    [owner, user] = await ethers.getSigners();

    const ERC20 = await ethers.getContractFactory("ERC20Mock");
    token = await ERC20.deploy("MOCK", "MOCK", owner.address, ethers.parseUnits("1000000", 18));
    await token.waitForDeployment();

    const NFTDiscount = await ethers.getContractFactory("NFTDiscount");
    nftDiscount = await NFTDiscount.deploy();
    await nftDiscount.waitForDeployment();

    const StakingModule = await ethers.getContractFactory("StakingModule");
    staking = await StakingModule.deploy(token.target, nftDiscount.target);
    await staking.waitForDeployment();

    await nftDiscount.setJackpotMinter(staking.target, true);
    await staking.setTreasury(owner.address);
  });

  it("mints 2 reward NFTs via mintJackpot and user receives 2 NFTs", async () => {
    await staking.pause();
    await staking.unpause();

    await staking.setRewardConfig(6, 2, 5);
    const config = await staking.rewardConfigs(6);
    expect(config.nftCount).to.equal(2);
    expect(config.discountPercent).to.equal(5);

    const amount = ethers.parseUnits("120", 18);
    await token.transfer(user.address, amount);
    await token.connect(user).approve(staking.target, amount);
    await staking.connect(user).stakeTokensFor(user.address, amount, 6);

    await ethers.provider.send("evm_increaseTime", [6 * 30 * 24 * 60 * 60]);
    await ethers.provider.send("evm_mine");

    await token.transfer(staking.target, ethers.parseUnits("200", 18));
    await staking.connect(user).unstakeTokensFor(user.address, 0);

    const balance = await nftDiscount.balanceOf(user.address);
    console.log("User NFT balance:", balance.toString());
    expect(balance).to.equal(2n);
  });
});
