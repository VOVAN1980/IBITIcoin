const { expect } = require("chai");
const { ethers, network } = require("hardhat");

describe("StakingModule", function() {
  let token, nftDiscount, staking;
  let owner, alice, treasury;

  beforeEach(async () => {
    [owner, alice, treasury] = await ethers.getSigners();

    // 1) Деплой мок‑ERC20 и выдача Alice 1000 токенов
    const ERC20Mock = await ethers.getContractFactory("ERC20Mock");
    token = await ERC20Mock.deploy(
      "MockToken",
      "MCK",
      alice.address,
      ethers.parseUnits("1000", 18)
    );
    await token.waitForDeployment();

    // 2) Переводим часть из Alice в Treasury для autoReplenish
    await token.connect(alice).transfer(
      treasury.address,
      ethers.parseUnits("500", 18)
    );

    // 3) Деплой NFTDiscount
    const NFTDiscount = await ethers.getContractFactory("NFTDiscount");
    nftDiscount = await NFTDiscount.deploy();
    await nftDiscount.waitForDeployment();

    // 4) Деплой StakingModule
    const Staking = await ethers.getContractFactory("StakingModule");
    staking = await Staking.deploy(token.target, nftDiscount.target);
    await staking.waitForDeployment();

    // 5) Настраиваем treasury и allowedCaller
    await staking.connect(owner).setTreasury(treasury.address);
    await staking.connect(owner).setAllowedCaller(owner.address);

    // 6) Разрешаем StakingModule чеканить Jackpot‑NFT в NFTDiscount
    await nftDiscount.connect(owner).setDAOModule(staking.target); // :contentReference[oaicite:0]{index=0}&#8203;:contentReference[oaicite:1]{index=1}
  });

  it("only owner can set treasury, rewardConfig, allowedCaller", async () => {
    await expect(
      staking.connect(alice).setTreasury(treasury.address)
    ).to.be.revertedWith("Ownable: caller is not the owner");
    await expect(
      staking.connect(alice).setRewardConfig(3, 5, 2)
    ).to.be.revertedWith("Ownable: caller is not the owner");
    await expect(
      staking.connect(alice).setAllowedCaller(alice.address)
    ).to.be.revertedWith("Ownable: caller is not the owner");
  });

  it("pause/unpause blocks stake and unstake", async () => {
    await staking.connect(owner).pause();
    await expect(
      staking.connect(alice).stakeTokensFor(alice.address, ethers.parseUnits("10",18), 3)
    ).to.be.revertedWith("Pausable: paused");
    await staking.connect(owner).unpause();

    // После unpause можно застейкать
    await token.connect(alice).approve(staking.target, ethers.parseUnits("10",18));
    await staking.connect(alice).stakeTokensFor(alice.address, ethers.parseUnits("10",18), 3);

    // Пауза блокирует и анстейк
    await staking.connect(owner).pause();
    await expect(
      staking.connect(alice).unstakeTokensFor(alice.address, 0)
    ).to.be.revertedWith("Pausable: paused");
  });

  it("stake and unstake on-time: principal+reward and NFT", async () => {
    // Alice stake 100 токенов на 3 месяца
    await token.connect(alice).approve(staking.target, ethers.parseUnits("100",18));
    await staking.connect(alice).stakeTokensFor(alice.address, ethers.parseUnits("100",18), 3);

    // Прокручиваем 3 месяца + 1 день
    await network.provider.send("evm_increaseTime", [ (30*3 + 1)*24*3600 ]);
    await network.provider.send("evm_mine");

    // Даем allowance treasury → staking для autoReplenish
    await token.connect(treasury).approve(staking.target, ethers.parseUnits("100",18)); // :contentReference[oaicite:2]{index=2}&#8203;:contentReference[oaicite:3]{index=3}

    // unstake: principal + reward 5% = 105
    await expect(() => staking.connect(alice).unstakeTokensFor(alice.address, 0))
      .to.changeTokenBalances(
        token,
        [staking, alice],
        [ ethers.parseUnits("-100",18), ethers.parseUnits("105",18) ]
      );

    // И два Jackpot‑NFT
    expect(await nftDiscount.balanceOf(alice.address)).to.equal(2);
  });

  it("early unstake applies penalty", async () => {
    await token.connect(alice).approve(staking.target, ethers.parseUnits("50",18));
    await staking.connect(alice).stakeTokensFor(alice.address, ethers.parseUnits("50",18), 3);

    // Прокручиваем 29 дней
    await network.provider.send("evm_increaseTime", [ 29*24*3600 ]);
    await network.provider.send("evm_mine");

    // penalty 5% = 2.5, payout = 47.5
    await expect(() => staking.connect(alice).unstakeTokensFor(alice.address, 0))
      .to.changeTokenBalances(
        token,
        [staking, alice],
        [ ethers.parseUnits("-47.5",18), ethers.parseUnits("47.5",18) ]
      );
  });

  it("expired unstake sends all principal to treasury", async () => {
    await token.connect(alice).approve(staking.target, ethers.parseUnits("20",18));
    await staking.connect(alice).stakeTokensFor(alice.address, ethers.parseUnits("20",18), 1);

    // 1 месяц + 180 дней grace + 1 день
    await network.provider.send("evm_increaseTime", [ (30 + 180 + 1)*24*3600 ]);
    await network.provider.send("evm_mine");

    await expect(() => staking.connect(alice).unstakeTokensFor(alice.address, 0))
      .to.changeTokenBalances(
        token,
        [staking, treasury],
        [ ethers.parseUnits("-20",18), ethers.parseUnits("20",18) ]
      );
  });

  it("reverts unstake if treasury not set", async () => {
    const Staking2 = await ethers.getContractFactory("StakingModule");
    const staking2 = await Staking2.deploy(token.target, nftDiscount.target);
    await staking2.waitForDeployment();

    await token.connect(alice).approve(staking2.target, ethers.parseUnits("10",18));
    await staking2.connect(alice).stakeTokensFor(alice.address, ethers.parseUnits("10",18), 1);
    await expect(
      staking2.connect(alice).unstakeTokensFor(alice.address, 0)
    ).to.be.revertedWith("Treasury not set");
  });
});
