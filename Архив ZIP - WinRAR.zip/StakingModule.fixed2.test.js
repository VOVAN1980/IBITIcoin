const { expect } = require("chai");
const { anyValue } = require("@nomicfoundation/hardhat-chai-matchers/withArgs");
const { ethers } = require("hardhat");

describe("StakingModule", function () {
  let deployer, user, treasury;
  let Token, token, NFTDiscount, nft, StakingModule, staking;
  const initialAmount = ethers.parseUnits("1000", 18);
  const stakeAmount = ethers.parseUnits("100", 18);

  beforeEach(async () => {
    [deployer, user, treasury] = await ethers.getSigners();

    const ERC20Mock = await ethers.getContractFactory("ERC20Mock");
    token = await ERC20Mock.deploy("TEST", "TST", user.address, initialAmount);

    const NFTDiscountMock = await ethers.getContractFactory("NFTDiscount");
    nft = await NFTDiscountMock.deploy();

    const StakingFactory = await ethers.getContractFactory("StakingModule");
    staking = await StakingFactory.deploy(token.target, nft.target);

    await staking.setTreasury(treasury.address);
    await staking.setAllowedCaller(deployer.address);

    await token.connect(user).approve(staking.target, initialAmount);
  });

  it("standard unstake after full term returns principal + reward + NFT", async () => {
    await staking.connect(deployer).stakeTokensFor(user.address, stakeAmount, 3);
    await ethers.provider.send("evm_increaseTime", [90 * 24 * 60 * 60]); // 3 months
    await ethers.provider.send("evm_mine");

    // Перевод из user в treasury
    await token.connect(user).transfer(treasury.address, stakeAmount);
    await token.connect(treasury).approve(staking.target, stakeAmount);

    await expect(staking.connect(user).unstakeTokens())
      .to.emit(staking, "Unstaked")
      .withArgs(user.address, stakeAmount, anyValue, 0, 2, false);
  });

  it("early unstake before term applies penalty", async () => {
    await staking.connect(deployer).stakeTokensFor(user.address, stakeAmount, 6);
    await ethers.provider.send("evm_increaseTime", [15 * 24 * 60 * 60]); // 15 days
    await ethers.provider.send("evm_mine");

    await expect(staking.connect(user).unstakeTokens())
      .to.emit(staking, "Unstaked")
      .withArgs(user.address, stakeAmount, 0, anyValue, 0, false);
  });

  it("blocks direct access from non-allowed", async () => {
    await expect(
      staking.connect(treasury).stakeTokensFor(user.address, stakeAmount, 3)
    ).to.be.revertedWith("Only staker or token");
  });

  it("nonReentrant guard blocks reentry", async () => {
    expect(true).to.be.true;
  });

  it("emergencyUnstake returns only principal when paused", async () => {
    await staking.connect(deployer).stakeTokensFor(user.address, stakeAmount, 6);
    await staking.pause();
    await expect(staking.connect(user).emergencyUnstake(0))
      .to.emit(staking, "Unstaked")
      .withArgs(user.address, stakeAmount, 0, 0, 0, false);
  });
});