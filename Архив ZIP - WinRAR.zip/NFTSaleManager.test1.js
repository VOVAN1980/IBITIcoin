// test/NFTSaleManager.test.js
const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("NFTSaleManager (uncovered cases)", function() {
  let owner, alice;
  let nftDiscount, ibitiToken, usdtToken, oracle, pair, saleMgr;

  beforeEach(async () => {
    [owner, alice] = await ethers.getSigners();

    // Deploy NFTDiscount and transfer ownership to saleMgr later
    const NFT = await ethers.getContractFactory("NFTDiscount", owner);
    nftDiscount = await NFT.deploy();
    await nftDiscount.waitForDeployment();

    // Deploy IBITI token mock (8 decimals)
    const ERC20Mock = await ethers.getContractFactory("ERC20Mock", owner);
    ibitiToken = await ERC20Mock.deploy("IBITI", "IBI", owner.address, ethers.parseUnits("1000000", 8));
    await ibitiToken.waitForDeployment();

    // Deploy USDT mock (8 decimals)
    usdtToken = await ERC20Mock.deploy("USDT", "USDT", owner.address, ethers.parseUnits("1000000", 8));
    await usdtToken.waitForDeployment();

    // Deploy VolumeWeightedOracle with decimals = 8
    const Oracle = await ethers.getContractFactory("VolumeWeightedOracle", owner);
    oracle = await Oracle.deploy(8);
    await oracle.waitForDeployment();

    // Deploy a mock UniswapV2Pair: reserve0 = 100, reserve1 = 200
    const Pair = await ethers.getContractFactory("MockUniswapV2Pair", owner);
    pair = await Pair.deploy(100, 200);
    await pair.waitForDeployment();

    // Add pool to oracle
    await oracle.addPool(pair.target);

    // Deploy NFTSaleManager
    const Sale = await ethers.getContractFactory("NFTSaleManager", owner);
    saleMgr = await Sale.deploy(
      nftDiscount.target,
      ibitiToken.target,
      usdtToken.target,
      oracle.target
    );
    await saleMgr.waitForDeployment();

    // Transfer NFTDiscount ownership to saleMgr so it can mint
    await nftDiscount.transferOwnership(saleMgr.target);

    // Set price for discountPercent=5 → 100 cents
    await saleMgr.setNFTPrice(5, 100);
  });

  it("reverts buyNFTWithIBITI when price not set", async () => {
    await expect(
      saleMgr.connect(alice).buyNFTWithIBITI(3, "ipfs://x")
    ).to.be.revertedWith("Price not set");
  });

  it("reverts buyNFTWithIBITI when oracle price is zero", async () => {
    // fresh NFTDiscount & oracle with no pools
    const NFT2 = await ethers.getContractFactory("NFTDiscount", owner);
    const nft2 = await NFT2.deploy(); await nft2.waitForDeployment();
    const Oracle2 = await ethers.getContractFactory("VolumeWeightedOracle", owner);
    const oracle2 = await Oracle2.deploy(8); await oracle2.waitForDeployment();
    const Sale2 = await ethers.getContractFactory("NFTSaleManager", owner);
    const sale2 = await Sale2.deploy(nft2.target, ibitiToken.target, usdtToken.target, oracle2.target);
    await sale2.waitForDeployment();
    await nft2.transferOwnership(sale2.target);
    await sale2.setNFTPrice(5, 100);
    await expect(
      sale2.connect(alice).buyNFTWithIBITI(5, "ipfs://no")
    ).to.be.revertedWith("Invalid IBITI price");
  });

  it("allows buyNFTWithIBITI at correct rate and mints NFT", async () => {
    // currentPrice = reserve1*1e8/reserve0 = 200*1e8/100 = 2e8
    const currentPrice = (200n * 10n**8n) / 100n; // 2e8
    // ibitiAmount = priceUSD*1e14/currentPrice = 100*1e14/2e8 = 5e7
    const expectedAmount = (100n * 10n**14n) / currentPrice; // 50,000,000
    await ibitiToken.transfer(alice.address, expectedAmount);
    await ibitiToken.connect(alice).approve(saleMgr.target, expectedAmount);

    await expect(
      saleMgr.connect(alice).buyNFTWithIBITI(5, "ipfs://token")
    )
      .to.emit(saleMgr, "NFTPurchased")
      .withArgs(alice.address, 5, expectedAmount, ibitiToken.target);

    expect(await nftDiscount.balanceOf(alice.address)).to.equal(1);
  });

  it("reverts buyNFTWithUSDT when price not set", async () => {
    await expect(
      saleMgr.connect(alice).buyNFTWithUSDT(3, "ipfs://z")
    ).to.be.revertedWith("Price not set");
  });

  it("allows buyNFTWithUSDT at correct rate and mints NFT", async () => {
    // set priceUSD=200 cents for discountPercent=7
    await saleMgr.setNFTPrice(7, 200);
    // usdtAmount = 200 * 10^(8-2) = 200 * 1e6 = 2e8
    const usdtAmount = 200n * 10n**6n;
    await usdtToken.transfer(alice.address, usdtAmount);
    await usdtToken.connect(alice).approve(saleMgr.target, usdtAmount);

    await expect(
      saleMgr.connect(alice).buyNFTWithUSDT(7, "ipfs://usdt")
    )
      .to.emit(saleMgr, "NFTPurchased")
      .withArgs(alice.address, 7, usdtAmount, usdtToken.target);

    expect(await nftDiscount.balanceOf(alice.address)).to.equal(1);
  });

  it("getCurrentIBITIPrice and getCurrentUSDTPrice return correct values", async () => {
    // IBITI price for discountPercent=5: 100*1e14/2e8 = 5e7
    const ibitiPrice = await saleMgr.getCurrentIBITIPrice(5);
    expect(ibitiPrice).to.equal((100n * 10n**14n) / ((200n * 10n**8n) / 100n));

    // USDT price: 100 * 10^(8-2) = 100 * 1e6 = 1e8
    const usdtPrice = await saleMgr.getCurrentUSDTPrice(5);
    expect(usdtPrice).to.equal(100n * 10n**6n);
  });
});
