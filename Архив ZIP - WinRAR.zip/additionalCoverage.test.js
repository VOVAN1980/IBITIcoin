const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("Additional Coverage Tests", function () {
  let owner, user;
  let tokenMock, feeManager, oracle, pairMock;

  before(async function () {
    [owner, user] = await ethers.getSigners();

    // 1) Deploy ERC20Mock as token contract for FeeManager
    const ERC20MockCF = await ethers.getContractFactory("ERC20Mock");
    tokenMock = await ERC20MockCF.deploy(
      "TKN",
      "TKN",
      owner.address,
      ethers.parseUnits("1000", 8)
    );
    await tokenMock.waitForDeployment();

    // 2) Deploy FeeManager with tokenMock address
    const FeeManagerCF = await ethers.getContractFactory("FeeManager");
    feeManager = await FeeManagerCF.deploy(tokenMock.target);
    await feeManager.waitForDeployment();

    // 3) Deploy a mock Uniswap V2 pair with known reserves
    const PairMockCF = await ethers.getContractFactory("MockUniswapV2Pair");
    pairMock = await PairMockCF.deploy(
      ethers.parseUnits("5", 18),  // reserve0
      ethers.parseUnits("10", 18)  // reserve1
    );
    await pairMock.waitForDeployment();

    // 4) Deploy VolumeWeightedOracle and add the mock pool
    const OracleCF = await ethers.getContractFactory("VolumeWeightedOracle");
    oracle = await OracleCF.deploy(18);
    await oracle.waitForDeployment();
    await oracle.addPool(pairMock.target);
  });

  describe("FeeManager calculateFee branches", function () {
    it("returns non-zero fee when no discount applied", async function () {
      const amount = ethers.parseUnits("100", 8);
      const fee = await feeManager.calculateFee(
        owner.address,
        amount,
        false, false, false, false,
        0,  // baseFeeBp
        0   // nftDiscountBp
      );
      expect(fee).to.be.a("bigint").and.to.be.gt(0);
    });

    it("returns 0 fee when nftDiscount >= 100 bp", async function () {
      const fee = await feeManager.calculateFee(
        user.address,
        ethers.parseUnits("50", 8),
        false, false, false, false,
        0,    // baseFeeBp
        100   // nftDiscountBp
      );
      expect(fee).to.equal(0);
    });

    it("returns 0 fee when nftDiscount > 100 bp", async function () {
      const fee = await feeManager.calculateFee(
        user.address,
        ethers.parseUnits("10", 8),
        false, false, false, false,
        0,
        101
      );
      expect(fee).to.equal(0);
    });
  });

  describe("VolumeWeightedOracle functionality", function () {
    it("calculates correct weighted price from one pool", async function () {
      // expected price = (r1 * 10**decimals) / r0 = (10 * 1e18) / 5 = 2e18
      const price = await oracle.getPrice();
      expect(price).to.equal(ethers.parseUnits("2", 18));
    });

    it("returns 0 when no pools configured", async function () {
      const OracleCF = await ethers.getContractFactory("VolumeWeightedOracle");
      const emptyOracle = await OracleCF.deploy(18);
      await emptyOracle.waitForDeployment();
      expect(await emptyOracle.getPrice()).to.equal(0);
    });
  });
});
