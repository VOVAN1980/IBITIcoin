const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("NFTSaleManager — full test", function () {
  let saleManager, nftDiscount, ibitiToken, usdtToken, oracle, pair;
  let owner, buyer;
  const DISCOUNT = 5;
  const PRICE_USD = 500; // $5.00 (в центах)

  beforeEach(async () => {
    [owner, buyer] = await ethers.getSigners();

    // NFTDiscount
    const NFTDiscount = await ethers.getContractFactory("NFTDiscount", owner);
    nftDiscount = await NFTDiscount.deploy();
    await nftDiscount.waitForDeployment();

    // ERC20 токены (8 дец.)
    const ERC20Mock = await ethers.getContractFactory("ERC20Mock", owner);
    ibitiToken = await ERC20Mock.deploy("IBITI", "IBI", owner.address, ethers.parseUnits("1000000", 8));
    usdtToken  = await ERC20Mock.deploy("USDT",  "USDT", owner.address, ethers.parseUnits("1000000", 8));
    await ibitiToken.waitForDeployment();
    await usdtToken.waitForDeployment();

    // Oracle и пара
    const Pair = await ethers.getContractFactory("MockUniswapV2Pair", owner);
    pair = await Pair.deploy(1000000, 2000000000); // reserve0 = 1e6, reserve1 = 2000e6
    const Oracle = await ethers.getContractFactory("VolumeWeightedOracle", owner);
    oracle = await Oracle.deploy(8);
    await oracle.waitForDeployment();
    await pair.waitForDeployment();
    await oracle.addPool(pair.target);

    // NFTSaleManager
    const Sale = await ethers.getContractFactory("NFTSaleManager", owner);
    saleManager = await Sale.deploy(
      nftDiscount.target,
      ibitiToken.target,
      usdtToken.target,
      oracle.target
    );
    await saleManager.waitForDeployment();

    // DAO-права на минт
    await nftDiscount.connect(owner).setDAOModule(saleManager.target);

    // Установка цен
    await saleManager.setNFTPrice(DISCOUNT, PRICE_USD);

    // Токены и allowance
    await ibitiToken.transfer(buyer.address, ethers.parseUnits("100", 8));
    await usdtToken.transfer(buyer.address, ethers.parseUnits("100", 8));
    await ibitiToken.connect(buyer).approve(saleManager.target, ethers.parseUnits("100", 8));
    await usdtToken.connect(buyer).approve(saleManager.target, ethers.parseUnits("100", 8));
  });

  it("should revert buyNFTWithIBITI when price not set", async () => {
    await saleManager.setNFTPrice(999, 0);
    await expect(
      saleManager.connect(buyer).buyNFTWithIBITI(999, "ipfs://unset")
    ).to.be.revertedWith("Price not set");
  });

  it("should revert buyNFTWithUSDT when price not set", async () => {
    await saleManager.setNFTPrice(888, 0);
    await expect(
      saleManager.connect(buyer).buyNFTWithUSDT(888, "ipfs://unset2")
    ).to.be.revertedWith("Price not set");
  });

  it("should revert if IBITI price from oracle is zero", async () => {
    const DummyOracle = await ethers.getContractFactory("VolumeWeightedOracle");
    const zeroOracle = await DummyOracle.deploy(8);
    const DummySale = await ethers.getContractFactory("NFTSaleManager");
    const brokenSale = await DummySale.deploy(
      nftDiscount.target,
      ibitiToken.target,
      usdtToken.target,
      zeroOracle.target
    );
    await brokenSale.waitForDeployment();
    await brokenSale.setNFTPrice(DISCOUNT, PRICE_USD);
    await nftDiscount.setDAOModule(brokenSale.target);
    await expect(
      brokenSale.connect(buyer).buyNFTWithIBITI(DISCOUNT, "ipfs://broken")
    ).to.be.revertedWith("Invalid IBITI price");
  });

  it("should buy NFT with IBITI and emit event", async () => {
    const price = await saleManager.getCurrentIBITIPrice(DISCOUNT);
    await ibitiToken.transfer(buyer.address, price);
    await ibitiToken.connect(buyer).approve(saleManager.target, price);

    await expect(
      saleManager.connect(buyer).buyNFTWithIBITI(DISCOUNT, "ipfs://ibi")
    ).to.emit(saleManager, "NFTPurchased")
      .withArgs(buyer.address, DISCOUNT, price, ibitiToken.target);
  });

  it("should buy NFT with USDT and emit event", async () => {
    const price = await saleManager.getCurrentUSDTPrice(DISCOUNT);
    await usdtToken.transfer(buyer.address, price);
    await usdtToken.connect(buyer).approve(saleManager.target, price);

    await expect(
      saleManager.connect(buyer).buyNFTWithUSDT(DISCOUNT, "ipfs://usdt")
    ).to.emit(saleManager, "NFTPurchased")
      .withArgs(buyer.address, DISCOUNT, price, usdtToken.target);
  });

  it("should return correct price in IBITI and USDT", async () => {
    const ibiti = await saleManager.getCurrentIBITIPrice(DISCOUNT);
    const usdt = await saleManager.getCurrentUSDTPrice(DISCOUNT);

    expect(ibiti).to.equal(250000);        // = (500 * 1e14) / 2000e8
    expect(usdt).to.equal(500000000);      // = 500 * 10^(8 - 2)
  });

  it("should emit events on setNFTPrice and updateOracle", async () => {
    const newOracle = ethers.Wallet.createRandom().address;
    await expect(saleManager.setNFTPrice(10, 999))
      .to.emit(saleManager, "PriceSet").withArgs(10, 999);

    await expect(saleManager.updateOracle(newOracle))
      .to.emit(saleManager, "OracleUpdated").withArgs(newOracle);
  });

  it("should revert getCurrent*Price when price is not set", async () => {
    await expect(saleManager.getCurrentIBITIPrice(99)).to.be.revertedWith("Price not set");
    await expect(saleManager.getCurrentUSDTPrice(99)).to.be.revertedWith("Price not set");
  });
});
