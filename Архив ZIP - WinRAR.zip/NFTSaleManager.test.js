const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("NFTSaleManager", function () {
  let saleManager;
  let nftDiscount;
  let ibitiToken, usdtToken, vwo, pair;
  let owner, buyer;
  const DISCOUNT = 5;        // уровень скидки
  const PRICE_USD = 200;     // 200 центов = $2.00

  beforeEach(async function () {
    [owner, buyer] = await ethers.getSigners();

    // 1) Деплоим NFTDiscount и разрешаем ему чеканить Jackpot‑NFT
    const NFTDiscount = await ethers.getContractFactory("NFTDiscount", owner);
    nftDiscount = await NFTDiscount.deploy();
    await nftDiscount.waitForDeployment();
    await nftDiscount.setDAOModule(owner.address);

    // 2) Мок‑токены (ERC20Mock) :contentReference[oaicite:0]{index=0}&#8203;:contentReference[oaicite:1]{index=1}
    const ERC20Mock = await ethers.getContractFactory("ERC20Mock", owner);
    ibitiToken = await ERC20Mock.deploy("IBITI", "IBT", owner.address, ethers.parseUnits("1000", 8));
    usdtToken  = await ERC20Mock.deploy("USDT",  "USDT", owner.address, ethers.parseUnits("1000", 8));

    // 3) Оракул и пара для VolumeWeightedOracle :contentReference[oaicite:2]{index=2}&#8203;:contentReference[oaicite:3]{index=3} :contentReference[oaicite:4]{index=4}&#8203;:contentReference[oaicite:5]{index=5}
    const MockUniswapV2Pair = await ethers.getContractFactory("MockUniswapV2Pair", owner);
    pair = await MockUniswapV2Pair.deploy(
      ethers.parseUnits("100", 8),
      ethers.parseUnits("400", 8)
    );
    const VWO = await ethers.getContractFactory("VolumeWeightedOracle", owner);
    vwo = await VWO.deploy(8);
    await vwo.addPool(pair.target);

    // 4) Деплоим NFTSaleManager, передаём адреса :contentReference[oaicite:6]{index=6}&#8203;:contentReference[oaicite:7]{index=7}
    const Sale = await ethers.getContractFactory("NFTSaleManager", owner);
    saleManager = await Sale.deploy(
      nftDiscount.target,
      ibitiToken.target,
      usdtToken.target,
      vwo.target
    );
    await saleManager.waitForDeployment();
    await nftDiscount.setDAOModule(saleManager.target);

    // 5) Устанавливаем цену (в центах) для уровня DISCOUNT
    await saleManager.setNFTPrice(DISCOUNT, PRICE_USD);
  });

  it("reverts buyNFTWithIBITI when price not set", async function () {
    await expect(
      saleManager.buyNFTWithIBITI(999, "ipfs://x")
    ).to.be.revertedWith("Price not set");
  });

  it("allows buyNFTWithIBITI at correct rate and mints NFT", async function () {
    // Узнаём требуемую сумму IBITI у контракта (формула ibitiAmount = priceUSD*10^14/currentPrice) :contentReference[oaicite:8]{index=8}&#8203;:contentReference[oaicite:9]{index=9}
    const required = await saleManager.getCurrentIBITIPrice(DISCOUNT);

    // Переводим buyer нужную сумму и даём allowance
    await ibitiToken.connect(owner).transfer(buyer.address, required);
    await ibitiToken.connect(buyer).approve(saleManager.target, required);

    await expect(
      saleManager.connect(buyer).buyNFTWithIBITI(DISCOUNT, "ipfs://cid")
    )
      .to.emit(saleManager, "NFTPurchased")
      .withArgs(buyer.address, DISCOUNT, required, ibitiToken.target);
  });

  it("reverts buyNFTWithUSDT when price not set", async function () {
    await expect(
      saleManager.buyNFTWithUSDT(999, "ipfs://y")
    ).to.be.revertedWith("Price not set");
  });

  it("allows buyNFTWithUSDT at correct rate and mints NFT", async function () {
    // Узнаём требуемую сумму USDT
    const requiredUSDT = await saleManager.getCurrentUSDTPrice(DISCOUNT);

    await usdtToken.connect(owner).transfer(buyer.address, requiredUSDT);
    await usdtToken.connect(buyer).approve(saleManager.target, requiredUSDT);

    await expect(
      saleManager.connect(buyer).buyNFTWithUSDT(DISCOUNT, "ipfs://cid2")
    )
      .to.emit(saleManager, "NFTPurchased")
      .withArgs(buyer.address, DISCOUNT, requiredUSDT, usdtToken.target);
  });

  it("getCurrentIBITIPrice and getCurrentUSDTPrice return correct values", async function () {
    const ibitiPrice = await saleManager.getCurrentIBITIPrice(DISCOUNT);
    const usdtPrice  = await saleManager.getCurrentUSDTPrice(DISCOUNT);

    // Проверяем, что методы возвращают одно и то же, что мы использовали в тестах выше
    expect(ibitiPrice).to.be.a("bigint");
    expect(usdtPrice).to.be.a("bigint");
  });
});
