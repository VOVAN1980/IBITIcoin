const { expect } = require("chai");
const { ethers }  = require("hardhat");
const { parseUnits } = ethers;

describe("StakingModule: full‑coverage", function () {
  let token, nft, staking;
  let owner, treasury, alice;
  const DEC   = 8;                         // токен имеет 8 dec
  const MONTH = 30 * 24 * 60 * 60;         // 30 дней
  const GRACE = 180 * 24 * 60 * 60;        // 180 дней

  /* ────────────── deployment ────────────── */
  beforeEach(async () => {
    [owner, treasury, alice] = await ethers.getSigners();

    /* ERC20Mock (8 dec) */
    const ERC20Mock = await ethers.getContractFactory("ERC20Mock");
    const initial   = parseUnits("2000000", DEC);        // 2 млн
    token = await ERC20Mock.deploy("IBI", "IBI", owner.address, initial);
    await token.waitForDeployment();

    /* распределим баланс */
    await token.transfer(treasury.address, parseUnits("1000000", DEC));
    await token.transfer(alice.address,    parseUnits("1000",    DEC));

    /* NFTDiscount + StakingModule */
    const NFTDiscount   = await ethers.getContractFactory("NFTDiscount");
    nft      = await NFTDiscount.deploy();
    await nft.waitForDeployment();

    const StakingModule = await ethers.getContractFactory("StakingModule");
    staking = await StakingModule.deploy(token.target, nft.target);
    await staking.waitForDeployment();

    /* настроим разрешения */
    await staking.setTreasury(treasury.address);           // куда идут штрафы
    await nft.setDAOModule(staking.target);                // модуль может mint‑ить Jackpot
    await token.connect(treasury)
                .approve(staking.target, parseUnits("1000000", DEC)); // для _autoReplenish
  });

  /* helper: проскочить время */
  async function warp(sec) {
    await ethers.provider.send("evm_increaseTime", [sec]);
    await ethers.provider.send("evm_mine");
  }

  /* ────────────── 1. within grace ────────────── */
  it("on‑time claim (<= grace): principal + reward + 2 NFT", async () => {
    const principal = parseUnits("100", DEC);              // 100 IBI
    await token.connect(alice).approve(staking.target, principal);
    await staking.connect(alice).stakeTokensFor(alice.address, principal, 3); // 3 мес

    await warp(4 * MONTH);                                 // 3 мес + 1 мес  (< grace)

    const before = await token.balanceOf(alice.address);
    await staking.connect(alice).unstakeTokensFor(alice.address, 0);
    const after  = await token.balanceOf(alice.address);

    const reward = principal * 5n / 100n;                  // 5 % за 3 месяца
    expect(after - before).to.equal(principal + reward);

    /* проверяем, что выдано 2 Jackpot‑NFT (enum = 5) */
    expect(await nft.mintedCount(5)).to.equal(2);
  });

  /* ────────────── 2. after grace ────────────── */
  it("expired claim (> grace): конфискация в казну", async () => {
    const principal = parseUnits("50", DEC);
    await token.connect(alice).approve(staking.target, principal);
    await staking.connect(alice).stakeTokensFor(alice.address, principal, 1); // 1 мес

    await warp(1 * MONTH + GRACE + 24 * 60 * 60);          // > grace

    const tBefore = await token.balanceOf(treasury.address);
    const aBefore = await token.balanceOf(alice.address);

    await staking.connect(alice).unstakeTokensFor(alice.address, 0);

    const tAfter = await token.balanceOf(treasury.address);
    const aAfter = await token.balanceOf(alice.address);

    expect(tAfter - tBefore).to.equal(principal);          // всё ушло в казну
    expect(aAfter).to.equal(aBefore);                      // Alice ничего не получила
  });

  /* ────────────── 3. early unstake ────────────── */
  it("early unstake (< term): штраф 10 %", async () => {
    const principal = parseUnits("200", DEC);
    await token.connect(alice).approve(staking.target, principal);
    await staking.connect(alice).stakeTokensFor(alice.address, principal, 5); // 5 мес

    await warp(1 * MONTH);                                 // рано

    const aBefore = await token.balanceOf(alice.address);
    await staking.connect(alice).unstakeTokensFor(alice.address, 0);
    const aAfter  = await token.balanceOf(alice.address);

    const penalty = principal * 10n / 100n;                // 10 % штраф
    expect(aAfter - aBefore).to.equal(principal - penalty); // получили меньше на 10 %
  });
});
