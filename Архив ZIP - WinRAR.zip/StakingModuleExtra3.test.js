const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("StakingModule Extra Tests", function () {
  let stakingModule, token, nftDiscount;
  let owner, staker, treasury;

  beforeEach(async function () {
    [owner, staker, treasury] = await ethers.getSigners();

    // Деплой тестового токена (ERC20Mock)
    const ERC20Mock = await ethers.getContractFactory("ERC20Mock");
    token = await ERC20Mock.deploy("TestToken", "TTK", owner.address, ethers.parseUnits("1000000", 8));
    await token.waitForDeployment();

    // Деплой NFTDiscount
    const NFTDiscount = await ethers.getContractFactory("NFTDiscount");
    nftDiscount = await NFTDiscount.deploy();
    await nftDiscount.waitForDeployment();

    // Деплой StakingModule. Конструктор ожидает два адреса: токена и NFTDiscount.
    const StakingModule = await ethers.getContractFactory("StakingModule");
    stakingModule = await StakingModule.deploy(token.target, nftDiscount.target);
    await stakingModule.waitForDeployment();

    // Перевод токенов стейкеру и установка allowance для StakingModule
    await token.transfer(staker.address, ethers.parseUnits("1000", 8));
    await token.connect(staker).approve(stakingModule.target, ethers.parseUnits("1000", 8));
  });

  it("should revert staking with zero amount", async function () {
    // Вызов stakeTokensFor с amount равным 0 должен вызвать revert.
    await expect(stakingModule.connect(staker).stakeTokensFor(staker, 0n, 3))
      .to.be.revertedWith("Amount zero");
  });

  it("should stake tokens successfully", async function () {
    const stakeAmount = ethers.parseUnits("100", 8);
    // Стейкаем 100 токенов на 3 месяца.
    await stakingModule.connect(staker).stakeTokensFor(staker, stakeAmount, 3);

    const count = await stakingModule.getStakeCount(staker);
    expect(count).to.equal(1);

    const stakeInfo = await stakingModule.getStakeInfo(staker, 0);
    expect(stakeInfo.amount).to.equal(stakeAmount);
  });

  it("should revert unstake if treasury is not set", async function () {
    const stakeAmount = ethers.parseUnits("100", 8);
    await stakingModule.connect(staker).stakeTokensFor(staker, stakeAmount, 3);
    await expect(stakingModule.connect(staker).unstakeTokensFor(staker, 0))
      .to.be.revertedWith("Treasury not set");
  });
});
